# V9 用户画像推理完整 Workflow：可复制搭建版

作者：Manus AI  
日期：2026-06-10  
适用场景：快手电商直播与短视频推荐中的用户理解、推荐策略白盒化、供给承接和巡检 Agent。

## 一、设计定位与落地边界

本文档基于项目内《用户画像推理输出结构 V9：极简字段说明版》和《V9 用户画像推理简易 Workflow 清洁版：节点输入输出与 Prompt 设计说明》两份定稿文件，进一步补齐**可直接复制到 Workflow 平台搭建的完整节点方案**。本文不仅给出 DAG、每个节点的输入和输出协议，也给出每个 LLM 节点可直接粘贴使用的 Prompt，并补充 P0、P1、Batch、A1 等代码节点的工程实现要求。

本 Workflow 的目标不是复盘用户所有历史行为，而是把用户行为、交易、搜索、内容互动、场域偏好、类目约束和风险信号，推理成 V9 标准画像结果。最终输出只保留一个用户标识字段和四个画像主体模块：`consumption_interest_profile`、`interest_scene_graph`、`content_anchor_delivery` 和 `negative_signal_radar`。版本号、任务 ID、生成时间、模型信息、运行链路信息等工程元信息不进入画像主体，应由外部任务表或日志系统管理。

> **核心原则**：消费人格回答“这个用户整体上是什么样的消费风格”；消费角色回答“用户以什么身份和责任关系购买”；兴趣场景回答“用户在什么语境下产生需求”；兴趣簇回答“该场景可由什么供给集合承接”；未满足兴趣类目回答“具体可探索哪个类目以及它是什么兴趣类型”；候选商品方向回答“可以用什么商品方向进行推荐试探”。

| 设计项 | 定稿选择 | 说明 |
| --- | --- | --- |
| 最终输出结构 | 严格遵循 V9 极简字段 | 不输出过程字段、证据全文、模型链路和调试元信息。 |
| 类目约束方式 | Start 上传 L1/L2 类目文件，P0 解析为白名单 | 类目表不是 LLM 推理节点，L1/L2 必须受控。 |
| 兴趣场景 | 自由生成具体场景，但最多 3 个核心场景 | 场景名称必须表达需求语境，不能等同类目名。 |
| 兴趣类型 | 落在未满足兴趣类目层 | 同一场景或兴趣簇内可能同时包含长期、短期、复购、季节和潜在探索兴趣。 |
| 价格带 | 落在类目和商品方向层 | 不输出全局价格带，避免把局部支付能力泛化为全局消费能力。 |
| 风险信号 | LLM-4 独立生成，只进入 A1 | 负向风险不进入 LLM-5，避免过早压制潜在兴趣发现。 |
| 最终质检 | A1 程序化校验 | 不设置 LLM 修复节点，失败时返回结构化错误。 |

## 二、完整 Workflow DAG

```mermaid
graph TD
    Start[Start: raw_user_json + category_l12_file + run_config] --> P0[Code P0: 输入解析、字段标准化、类目表解析]
    P0 --> P1[Code P1: 证据卡片构建]

    P1 --> L1[LLM-1: 消费人格、消费角色、消费能力推理]
    P1 --> L2[LLM-2: 兴趣候选与类目意图初判]
    P1 --> L3[LLM-3: 内容触达与场域偏好推理]
    P1 --> L4[LLM-4: 负向信号与风险雷达]

    L1 --> L5[LLM-5: 兴趣场景-兴趣簇-兴趣类目泛化归并]
    L2 --> L5
    P1 --> L5
    P0 --> L5

    L5 --> B1[Batch: 按兴趣场景拆分]
    B1 --> L6[LLM-6: 单场景候选商品方向补全]

    L1 --> A1[Code A1: 最终装配与 Schema 质检]
    L3 --> A1
    L4 --> A1
    L5 --> A1
    L6 --> A1
    P0 --> A1
    A1 --> End[End: V9 JSON 或结构化错误]
```

`LLM-1`、`LLM-2`、`LLM-3` 和 `LLM-4` 可并行执行。`LLM-5` 是核心归并节点，只读取正向证据、兴趣候选、消费画像和类目白名单，不读取负向风险。`LLM-6` 通过 Batch 按兴趣场景并行执行，负责把每个场景下的兴趣簇补全为候选商品方向、推荐价格带、卖点逻辑和内容触发方式。A1 是唯一的最终装配与程序化质检节点。

| 节点 | 类型 | 上游 | 核心职责 | 核心输出 |
| --- | --- | --- | --- | --- |
| Start | 输入 | 无 | 接收用户 JSON、类目文件和运行配置 | 原始输入 |
| P0 | Code | Start | 标准化输入、解析类目表、生成配置和输入质检 | `std_user`、`cat_l12_map`、`run_config_norm`、`input_qc` |
| P1 | Code | P0 | 将复杂输入压缩成 LLM 可消费证据卡片 | 六类证据卡片 |
| LLM-1 | LLM | P1 | 推理消费人格、多角色画像和消费能力 | `persona_profile`、`consumption_profile`、`role_profile`、`spend_power_profile` |
| LLM-2 | LLM | P1、P0 | 推理兴趣候选和类目意图 | `interest_candidates`、`category_intent_cards` |
| LLM-3 | LLM | P1 | 推理内容、主播和场域触达画像 | `content_delivery_profile` |
| LLM-4 | LLM | P1 | 推理负向信号和推荐风险边界 | `negative_signal_radar` |
| LLM-5 | LLM | LLM-1、LLM-2、P1、P0 | 归并兴趣场景、兴趣簇和未满足兴趣类目骨架 | `interest_scene_graph_skel` |
| Batch | Batch/Code | LLM-5、LLM-1、P1、P0 | 按场景拆分给 LLM-6 | 单场景输入数组 |
| LLM-6 | LLM | Batch | 补全候选商品方向和类目级价格带 | `product_direction_cards` |
| A1 | Code | 全部上游 | 装配 V9 JSON，做 Schema、枚举、数量、类目和风险质检 | V9 JSON 或结构化错误 |

## 三、Start 节点设计

Start 节点接收三个输入，其中 `raw_user_json` 和 `category_l12_file` 必填，`run_config` 可选。类目表作为独立文件输入，不混入用户行为 JSON，避免平台约束输入和用户行为输入混淆。

| 输入字段 | 类型 | 是否必填 | 说明 | 示例 |
| --- | --- | --- | --- | --- |
| `raw_user_json` | JSON 或字符串化 JSON | 是 | 单个用户的基础信息、交易、搜索、商品行为、内容互动、退款、负反馈、场域等原始字段。 | `mengchao测试数据_cleaned.json` |
| `category_l12_file` | 文件 | 是 | 平台一级/二级类目表，至少包含 `category_level_1_name` 和 `category_level_2_name`。 | CSV、TSV、XLSX |
| `run_config` | JSON | 否 | 控制数量上限和调试开关。 | `{"max_scenes":3,"max_clusters_per_scene":3,"max_categories_per_cluster":5,"debug":true}` |

建议 Start 输出给 P0 的结构如下。

```json
{
  "raw_user_json": "{{Start.raw_user_json}}",
  "category_l12_file": "{{Start.category_l12_file}}",
  "run_config": "{{Start.run_config}}"
}
```

## 四、P0：输入解析、字段标准化与类目表解析

P0 是确定性代码节点。它只做解析、归一、空值处理、字段兼容、类目表解析、配置归一和输入质检，不做人格、兴趣、场景、价格带或风险推理。

### 4.1 P0 输入

```json
{
  "raw_user_json": "{{Start.raw_user_json}}",
  "category_l12_file": "{{Start.category_l12_file}}",
  "run_config": "{{Start.run_config}}"
}
```

### 4.2 P0 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "std_user": {
    "user_id": "",
    "basic_profile": {},
    "item_behavior": [],
    "trade_profile": {},
    "trade_category_stats": [],
    "trade_brand_stats": [],
    "recent_orders": [],
    "negative_feedback": [],
    "signal_correction": [],
    "refund_profile": {},
    "content_behavior": [],
    "anchor_trust_profile": {},
    "field_preference": [],
    "ecom_comment_texts": [],
    "search_queries": []
  },
  "cat_l12_map": {
    "服饰/鞋靴": ["服饰", "鞋靴", "未知", "其他服饰/鞋靴"]
  },
  "cat_l1_list": ["服饰/鞋靴"],
  "cat_l2_pairs": [
    {
      "category_level_1_name": "服饰/鞋靴",
      "category_level_2_name": "服饰"
    }
  ],
  "cat_fallback_rules": {
    "unknown_l2_allowed": true,
    "other_l2_allowed": true,
    "l3_generated_by_llm": true
  },
  "run_config_norm": {
    "max_scenes": 3,
    "max_clusters_per_scene": 3,
    "max_categories_per_cluster": 5,
    "debug": true
  },
  "input_qc": {
    "missing_fields": [],
    "category_file_rows": 0,
    "category_duplicate_rows": 0,
    "sparse_modules": []
  }
}
```

### 4.3 P0 字段标准化规则

P0 应尽量把真实业务输入适配到稳定的标准对象中。后续新增或调整大宽表字段时，优先修改 P0/P1，不轻易改 LLM 节点接口。

| 原始模块 | P0 标准对象 | 标准化要求 | 下游用途 |
| --- | --- | --- | --- |
| `user_id` 或 `uid` | `std_user.user_id` | 转成字符串；缺失时可使用外部任务 ID，但应标记 `missing_fields`。 | A1 输出 `uid`。 |
| `user_basic_info` | `basic_profile` | 城市、设备、U 分层、年龄段、性别等缺失统一为 `unknown`；只作为弱证据。 | LLM-1、LLM-5、LLM-6。 |
| `item_interaction` | `item_behavior[]` | 从字段名解析时间窗、行为类型、类目和值；过滤 0 值。 | LLM-2、LLM-5、LLM-6。 |
| `trade_data` | `trade_profile`、`trade_category_stats`、`recent_orders` | 保留订单时间、金额、商品名、L1/L2/L3、品牌、场域、退款状态和退款原因。 | LLM-1、LLM-2、LLM-5、LLM-6。 |
| `negative_feedback` | `negative_feedback[]` | 解析类目、内容垂类、负反馈类型和值；不得直接等同绝对不感兴趣。 | LLM-4、A1。 |
| `signal_correction` | `signal_correction[]` | 与负反馈同维度对齐，用于区分真实负向和内容形态分歧。 | LLM-3、LLM-4。 |
| `refund_metrics` | `refund_profile` | 分母为 0 时退款率为 `null`，并标记稀疏。 | LLM-1、LLM-4、A1。 |
| `ecom_content` | `content_behavior[]` | 内容垂类只代表内容语义，不直接等同商品类目。 | LLM-3、LLM-5。 |
| `anchor_trust` | `anchor_trust_profile` | 计算直播 GMV 占比；不能单点等同“喜欢直播”。 | LLM-1、LLM-3。 |
| `field_order_stats` | `field_preference[]` | 统一搜索、商城、直播、短视频、店铺等场域命名。 | LLM-1、LLM-3、LLM-6。 |
| `search_query_list_30d` | `search_queries[]` | 去重、归一、识别品牌词/类目词/场景词/价格词。 | LLM-2、LLM-5、LLM-6。 |
| `category_l12_file` | `cat_l12_map` | 清洗 L1/L2 空格、重复行和异常值；构造白名单和隶属关系。 | LLM-2、LLM-5、LLM-6、A1。 |

### 4.4 P0 异常处理

| 异常 | 判断规则 | 输出 |
| --- | --- | --- |
| 用户 JSON 无效 | 解析失败、为空、顶层结构不可用 | `inputValidation=false`，`error_code=ERR_INPUT_JSON_INVALID`，`error_text=用户 JSON 为空或无法解析。` |
| 类目文件无效 | 文件为空、无法读取、格式不可解析 | `inputValidation=false`，`error_code=ERR_CATEGORY_FILE_INVALID`，`error_text=类目文件为空或无法解析。` |
| 类目表字段缺失 | 缺少 `category_level_1_name` 或 `category_level_2_name` | `inputValidation=false`，`error_code=ERR_CATEGORY_COLUMN_MISSING`，`error_text=类目文件缺少一级或二级类目列。` |
| 类目表为空 | 清洗后无合法 L1/L2 | `inputValidation=false`，`error_code=ERR_CATEGORY_TABLE_EMPTY`，`error_text=类目表清洗后无合法类目。` |

## 五、P1：证据卡片构建

P1 是确定性代码节点，负责把复杂输入压缩成 LLM 可消费的证据卡片。P1 可以聚合、排序、分桶、打强弱标记和生成稀疏提示，但不能直接输出“用户是什么消费人格”“用户有什么兴趣场景”这类结论。

### 5.1 P1 输入

```json
{
  "std_user": "{{P0.std_user}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "cat_l1_list": "{{P0.cat_l1_list}}",
  "cat_l2_pairs": "{{P0.cat_l2_pairs}}",
  "run_config_norm": "{{P0.run_config_norm}}",
  "input_qc": "{{P0.input_qc}}"
}
```

### 5.2 P1 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "evi_digest": {
    "user_ref": "string",
    "overall_summary": "string",
    "strong_signal_top": [],
    "sparse_modules": [],
    "conflict_modules": [],
    "time_window_coverage": {
      "7d": false,
      "14d": false,
      "30d": false,
      "90d": false,
      "180d": false
    }
  },
  "role_evi_cards": [],
  "price_evi_cards": [],
  "interest_evi_cards": [],
  "content_evi_cards": [],
  "risk_evi_cards": [],
  "category_constraint_cards": []
}
```

### 5.3 证据卡片格式

每类证据卡片建议采用一致的基础结构，便于 LLM 读取和引用。字段可以根据证据类型扩展，但基础字段不建议删除。

```json
{
  "card_id": "EVI_001",
  "evidence_type": "trade/search/item_behavior/content/field/risk/category_constraint/basic",
  "evidence_text": "可被 LLM 直接阅读的一句话证据",
  "source_fields": ["原始字段路径1", "原始字段路径2"],
  "related_category": {
    "category_level_1_name": "",
    "category_level_2_name": "",
    "category_level_3_name": ""
  },
  "time_window": "7d/14d/30d/90d/180d/unknown",
  "strength": "strong/medium/weak",
  "recency": "recent/mid_term/long_term/unknown",
  "value": null,
  "caveat": "证据限制或注意事项"
}
```

### 5.4 P1 证据构建要求

| 输出字段 | 内容 | 构建要求 |
| --- | --- | --- |
| `evi_digest` | 整体摘要、强信号 Top、稀疏模块、冲突模块、时间窗覆盖 | 控制长度，提供全局上下文；不要下最终画像结论。 |
| `role_evi_cards` | 自用、家庭、照护、礼赠、兴趣、价格优化、品质升级、内容种草等角色证据 | 每张卡包含证据类型、证据文本、强度和 caveat。 |
| `price_evi_cards` | 类目均价、P90、最高单笔、订单中位数、优惠词、设备弱证据、退款率 | 区分全局消费能力和类目级价格锚点。 |
| `interest_evi_cards` | 搜索、点击、商详、订单、DSP 类目、时序趋势、复购迹象 | 先按类目归并，再按时间窗和行为强度排序。 |
| `content_evi_cards` | 内容垂类、停留、完播、正向互动、直播 GMV、场域偏好 | 内容垂类迁移到商品类目时标记 `migration_risk`。 |
| `risk_evi_cards` | 退款、快速滑走、正负校正、类目噪声、内容-only、高价过推风险 | 只输出风险和约束，不直接删除兴趣候选。 |
| `category_constraint_cards` | L1/L2 白名单、L2-L1 隶属、未知/其他兜底 | 强制 L1/L2 命中白名单。 |

## 六、LLM-1：消费人格、消费画像、消费角色与消费能力推理

LLM-1 是稳定画像推理节点，负责回答用户整体上如何消费、主要以哪些角色购买、在平台内呈现什么消费能力，以及这些角色如何共同构成最终 V9 的消费兴趣画像。该节点输出的 `consumption_profile` 是中间协议，A1 会映射为最终 V9 的 `consumption_interest_profile`。

### 6.1 LLM-1 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "role_evi_cards": "{{P1.role_evi_cards}}",
  "price_evi_cards": "{{P1.price_evi_cards}}",
  "interest_evi_cards": "{{P1.interest_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}"
}
```

### 6.2 LLM-1 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "persona_profile": {
    "persona_name": "审慎型品质实用派",
    "persona_summary": "该用户在平台内呈现以实用补给和价格确定性为主的消费风格，在有证据类目中可能存在局部品质上探，但不应把局部高客单能力泛化为全局高消费力。",
    "persona_tags": {
      "vals_layer": "第二层-效率实用与家庭责任",
      "vals_type": "精明理性型",
      "vals_tribe": "精明消费族"
    },
    "core_traits": ["重视价格确定性", "偏好实用补给", "高客单需类目证据支持"],
    "confidence": 0.72
  },
  "consumption_profile": {
    "dominant_role_summary": "以自用实用和价格优化为主，存在内容种草或局部品质升级的辅助信号。",
    "role_mix": [
      {
        "role_code": "price_optimizer",
        "role_label": "价格优化型消费者",
        "rank": 1,
        "role_target": "给自己或家庭日常使用场景购买",
        "role_motivation": "用较低试错成本满足明确需求",
        "decision_focus": ["性价比", "优惠确定性", "实用功能"],
        "price_sensitivity": "高，适合 entry/value 价格带承接",
        "trust_requirement": "需要价格透明、真实评价和低风险售后承诺",
        "confidence": 0.78,
        "evidence": ["证据1", "证据2"]
      }
    ],
    "rejected_roles": [
      {
        "role_code": "gift_buyer",
        "reason": "缺少送礼、礼盒、节日对象等证据。"
      }
    ]
  },
  "role_profile": {
    "primary_roles": ["price_optimizer", "self_use_pragmatic"],
    "secondary_roles": ["trend_follower"],
    "role_confidence": 0.76
  },
  "spend_power_profile": {
    "spend_power_code": "lower_mid",
    "spend_power_label": "谨慎型中低消费力",
    "price_sensitivity": "高",
    "cat_price_elasticity": [
      {
        "category_hint": "有证据类目",
        "elasticity_level": "limited_upward",
        "reason": "仅在历史订单或搜索强证据支持的类目内允许轻度上探。"
      }
    ],
    "reasoning": ["证据1", "证据2"]
  },
  "persona_safety_check": {
    "passed": true,
    "blocked_terms": [],
    "rewritten_phrases": [],
    "notes": "所有人格表达均已转为消费决策、商品需求或触达策略语言。"
  }
}
```

### 6.3 LLM-1 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的“消费人格、消费角色与消费能力推理节点”。你的任务是基于上游证据卡片，推理单个用户在电商直播、短视频、泛货架和搜索等场域中的消费风格、主导消费角色、角色组合、平台内消费能力和价格敏感方式，并输出严格 JSON。

你只能使用输入 JSON 中已经提供的证据卡片进行判断。字段缺失、为空、为 null、为空数组、为 unknown 或无法理解时，一律按未知处理。不得补猜用户收入、真实年龄、婚育状态、家庭结构、身体状态、职业、外貌、地域偏见、真实身份或其他无法从字段验证的信息。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "role_evi_cards": {{P1.role_evi_cards}},
  "price_evi_cards": {{P1.price_evi_cards}},
  "interest_evi_cards": {{P1.interest_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}}
}

【你的推理目标】
第一，生成一个可展示的消费人格 persona_profile，用于概括用户整体消费风格。消费人格必须是中性、专业、策略可用的电商消费语言，不得评价用户身份、收入、外貌、年龄或价值观。
第二，生成 consumption_profile，表达用户可能并存的消费角色组合。角色可以多选，但必须主次有序，不要为了覆盖而凑角色。
第三，生成 role_profile，用于给下游场景归并节点快速读取主角色和辅助角色。
第四，生成 spend_power_profile，表达用户在平台内呈现出的消费能力、价格敏感方式和类目级支付弹性。消费能力不是收入判断，必须基于交易、价格、订单、退款、搜索、类目和场域证据综合判断。
第五，进行 persona_safety_check，确保输出没有敏感、冒犯、刻板或不可验证表达。

【China-VALS 标签约束】
persona_tags 必须包含以下三个字段，且只能从受控集合中选择：
1. vals_layer 只能从以下三项选择：
- 第一层-基础保障与价格安全
- 第二层-效率实用与家庭责任
- 第三层-自我实现与品质生活
2. vals_type 只能从以下六项选择：
- 精明理性型
- 审慎品质型
- 实用享乐混合型
- 家庭责任型
- 内容种草型
- 圈层投入型
3. vals_tribe 只能从以下十四项选择：
- 精明消费族
- 低门槛试探族
- 稳定补给族
- 家庭照护族
- 品质升级族
- 品牌信任族
- 内容种草族
- 达人口碑族
- 圈层兴趣族
- 任务筹备族
- 节令应景族
- 礼赠体面族
- 健康管理族
- 证据稀疏待观察族

【消费角色 taxonomy】
role_code 只能从以下 10 个枚举中选择：
- self_use_pragmatic：自用实用型消费者，以本人日常使用、刚需补给、功能满足为主。
- self_pleasing：悦己改善型消费者，为提升外在、健康、情绪、体验或生活品质而消费。
- family_buyer：家庭采购者，为家庭共同生活、家务、食品、清洁、耐用品采购。
- caregiver：照护责任承担者，为儿童、老人、宠物或特殊照护对象购买。只能基于商品证据表达，不得推断真实家庭结构。
- gift_buyer：礼赠社交型消费者，为送礼、人情、节日、关系维护进行购买。必须有礼盒、送礼词、节日对象、包装或节前购买证据。
- hobby_investor：兴趣投入型消费者，围绕爱好、圈层、专业设备或收藏投入。
- trend_follower：内容种草跟随者，受达人、直播、短视频、爆款内容影响明显。
- price_optimizer：价格优化型消费者，对优惠、比价、性价比和低价风险控制高度敏感。
- quality_upgrader：品质升级型消费者，在有证据类目中愿意为品质、品牌或耐用性支付溢价。
- uncertain_sparse：证据稀疏待观察用户，行为数据不足，无法稳定判断角色。

【消费能力分层约束】
spend_power_code 与 spend_power_label 必须对应如下五档：
- low：低消费力。交易稀疏或长期低客单，对高价和高决策成本商品承受力弱。
- lower_mid：谨慎型中低消费力。有一定购买能力，但明显偏谨慎，依赖优惠、低价、组合装、熟悉类目或确定性。
- mid：中等消费力。具备稳定平台消费能力，可接受多数日用、服饰、食品、家清等类目的中位价格带。
- upper_mid：品质型中高消费力。在有证据类目中具备品质、品牌或耐用品价格上探能力。
- high：高消费力。稳定高客单支付能力明确，对高品质、专业化或品牌化商品承受力强。

消费能力判断必须遵守以下规则：
1. 订单金额、类目均价、P90、有效订单、退款、价格敏感词、搜索和购买频次优先于城市、设备、年龄、性别、U 分层等基础信息。
2. 高频购买不等于高消费力；如果主要是 9.9—29.9 元日用小件，更可能是谨慎型中低消费力或稳定补给型。
3. 低频购买不等于低消费力；如果存在明确高客单耐用品、珠宝、数码、家电等有效订单，可在对应类目中说明支付弹性。
4. 局部高客单能力不能泛化为全局高消费力，必须在 cat_price_elasticity 中表达类目边界。
5. 内容种草可以提升兴趣判断，但不能单独提升消费能力。
6. 高退款、强负反馈或证据稀疏时，消费能力判断应保守。

【安全治理规则】
允许输出：理性务实、精打细算、品质升级、价格确定性、功能确定性、内容种草、圈层兴趣、家庭照护需求、照护责任线索。
禁止输出：穷、低端、土、虚荣、贪便宜、爱占便宜、容易被割韭菜、冲动无脑、盲从、大妈、宝妈、胖、瘦、有病、身体差、低收入、底层、已婚、单身等身份、外貌、身体、收入或贬损性表达。
如果证据指向敏感对象，只能表达为“照护类商品需求”“家庭共同使用需求”“儿童用品相关商品证据”，不得推断真实身份和家庭结构。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。所有 confidence 必须是 0 到 1 的数字。core_traits 输出 3 到 5 条。role_mix 输出 1 到 4 个角色，按 rank 升序排列。每个角色必须有 evidence，但 evidence 只需引用证据摘要，不要复制过长原文。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "persona_profile": {
    "persona_name": "string",
    "persona_summary": "string",
    "persona_tags": {
      "vals_layer": "第一层-基础保障与价格安全/第二层-效率实用与家庭责任/第三层-自我实现与品质生活",
      "vals_type": "精明理性型/审慎品质型/实用享乐混合型/家庭责任型/内容种草型/圈层投入型",
      "vals_tribe": "精明消费族/低门槛试探族/稳定补给族/家庭照护族/品质升级族/品牌信任族/内容种草族/达人口碑族/圈层兴趣族/任务筹备族/节令应景族/礼赠体面族/健康管理族/证据稀疏待观察族"
    },
    "core_traits": ["string"],
    "confidence": 0.0
  },
  "consumption_profile": {
    "dominant_role_summary": "string",
    "role_mix": [
      {
        "role_code": "self_use_pragmatic/self_pleasing/family_buyer/caregiver/gift_buyer/hobby_investor/trend_follower/price_optimizer/quality_upgrader/uncertain_sparse",
        "role_label": "string",
        "rank": 1,
        "role_target": "string",
        "role_motivation": "string",
        "decision_focus": ["string"],
        "price_sensitivity": "string",
        "trust_requirement": "string",
        "confidence": 0.0,
        "evidence": ["string"]
      }
    ],
    "rejected_roles": [
      {
        "role_code": "string",
        "reason": "string"
      }
    ]
  },
  "role_profile": {
    "primary_roles": ["string"],
    "secondary_roles": ["string"],
    "role_confidence": 0.0
  },
  "spend_power_profile": {
    "spend_power_code": "low/lower_mid/mid/upper_mid/high",
    "spend_power_label": "低消费力/谨慎型中低消费力/中等消费力/品质型中高消费力/高消费力",
    "price_sensitivity": "高/中高/中/中低/低/未知",
    "cat_price_elasticity": [
      {
        "category_hint": "string",
        "elasticity_level": "no_upward/limited_upward/moderate_upward/strong_upward/unknown",
        "reason": "string"
      }
    ],
    "reasoning": ["string"]
  },
  "persona_safety_check": {
    "passed": true,
    "blocked_terms": [],
    "rewritten_phrases": [],
    "notes": "string"
  }
}

如果输入证据整体为空或无法理解，输出 inputValidation=false，error_code=ERR_LLM1_INPUT_EMPTY，error_text=消费画像推理输入为空或无法理解，并保持其他字段为空对象或空数组。
```

## 七、LLM-2：兴趣候选与类目意图初判

LLM-2 从商品行为、搜索、订单、DSP 类目兴趣和时序证据中识别候选兴趣。它只生成候选，不生成最终兴趣场景，也不做过度泛化。它必须遵守 L1/L2 白名单，L3 只能作为 hint。

### 7.1 LLM-2 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "interest_evi_cards": "{{P1.interest_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "category_constraint_cards": "{{P1.category_constraint_cards}}",
  "cat_l12_map": "{{P0.cat_l12_map}}"
}
```

### 7.2 LLM-2 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_candidates": [
    {
      "candidate_id": "cand_001",
      "interest_type": "short_term",
      "category_level_1_name": "服饰/鞋靴",
      "category_level_2_name": "服饰",
      "category_level_3_name_hint": "薄款短袜",
      "intent_strength": "strong",
      "confidence": 0.82,
      "evidence": ["证据1", "证据2"],
      "time_sensitivity": "near_term",
      "source_signal_mix": ["search", "item_detail_view"],
      "notes": "近期搜索与商详浏览集中，具备短期转化可能。"
    }
  ],
  "category_intent_cards": [
    {
      "category_level_1_name": "服饰/鞋靴",
      "category_level_2_name": "服饰",
      "candidate_ids": ["cand_001"],
      "overall_intent_strength": "strong"
    }
  ],
  "unmapped_candidates": []
}
```

### 7.3 LLM-2 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的“兴趣候选与类目意图初判节点”。你的任务是基于用户的搜索、商品点击、商详、订单、DSP 类目兴趣、内容行为和类目约束，识别可能存在的电商兴趣候选，并输出严格 JSON。

你只负责生成兴趣候选，不负责生成最终兴趣场景，不负责生成兴趣簇，不负责生成候选商品方向，不负责判断价格带。你不能因为少量内容停留就把内容兴趣直接升级为强购买意图。你必须遵守 L1/L2 类目白名单，任何不在白名单中的一级或二级类目候选必须进入 unmapped_candidates，不能进入 interest_candidates。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "interest_evi_cards": {{P1.interest_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "category_constraint_cards": {{P1.category_constraint_cards}},
  "cat_l12_map": {{P0.cat_l12_map}}
}

【兴趣类型枚举】
interest_type 只能从以下五个值中选择：
- long_term：长期兴趣。跨较长周期稳定存在的类目偏好，不依赖单次近期行为触发。
- short_term：短期兴趣。未来 1—3 天内更可能发生搜索、点击、加购或订单的电商类目兴趣。
- silent_reactivatable：沉默可唤醒兴趣。历史有强兴趣或强购买证据，近期沉默，但存在重新唤醒可能。
- periodic_repurchase：周期/复购性兴趣。由消耗周期、复购间隔、生活周期或购买节律驱动的再购买兴趣。
- potential_exploratory：探索/潜在新兴趣。尚未充分显性表达，但可由弱信号、内容兴趣或电商场景迁移推理出的可能兴趣。

【意图强度规则】
intent_strength 只能输出 strong、medium、weak、unknown。
1. strong：存在搜索、商详、加购、支付、连续点击、多源一致等强电商行为。
2. medium：存在单一强信号或多个中等信号，但交易闭环或时序稳定性不足。
3. weak：主要来自内容行为、弱点击、DSP 兴趣或相邻类目迁移。
4. unknown：证据不足或信号冲突严重。

【证据优先级】
1. 搜索、商详、加购、支付订单是强电商意图。
2. 近 7/14 天行为强于 30/90/180 天行为。
3. 多源一致强于单源行为。
4. 内容停留、完播、正向互动只能作为内容兴趣或潜在探索证据，不能单独作为 strong。
5. 负反馈不在本节点用于删除候选；负反馈由 LLM-4 处理。

【类目约束】
1. category_level_1_name 必须是 cat_l12_map 的 key。
2. category_level_2_name 必须出现在 cat_l12_map[category_level_1_name] 中。
3. category_level_3_name_hint 可以由模型根据商品名、搜索词、订单和 L2 约束推理，但必须是商品供给粒度，不得是品牌词、场景词、抽象需求词或过泛词。
4. 如果候选无法挂靠合法 L1/L2，必须放入 unmapped_candidates，并说明原因。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。interest_candidates 最多输出 12 个，按 intent_strength、confidence、近期性和证据强度降序排列。category_intent_cards 需要按 L1/L2 汇总候选，不能编造不在 interest_candidates 中的 candidate_id。所有 confidence 必须是 0 到 1 的数字。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_candidates": [
    {
      "candidate_id": "cand_001",
      "interest_type": "long_term/short_term/silent_reactivatable/periodic_repurchase/potential_exploratory",
      "category_level_1_name": "string",
      "category_level_2_name": "string",
      "category_level_3_name_hint": "string",
      "intent_strength": "strong/medium/weak/unknown",
      "confidence": 0.0,
      "evidence": ["string"],
      "time_sensitivity": "near_term/mid_term/long_term/no_clear_time_window",
      "source_signal_mix": ["search/item_click/item_detail_view/cart/pay/content/dsp/field/other"],
      "notes": "string"
    }
  ],
  "category_intent_cards": [
    {
      "category_level_1_name": "string",
      "category_level_2_name": "string",
      "candidate_ids": ["cand_001"],
      "overall_intent_strength": "strong/medium/weak/unknown"
    }
  ],
  "unmapped_candidates": [
    {
      "raw_candidate_name": "string",
      "reason": "string",
      "evidence": ["string"]
    }
  ]
}

如果输入证据整体为空或类目白名单为空，输出 inputValidation=false，error_code=ERR_LLM2_INPUT_EMPTY 或 ERR_LLM2_CATEGORY_EMPTY，并在 error_text 中说明原因。
```

## 八、LLM-3：内容触达与场域偏好推理

LLM-3 只回答“如何触达这个用户更可能有效”，不负责兴趣泛化。它将内容垂类、停留、完播、正向互动、直播 GMV、场域购买等证据转成 V9 的 `content_anchor_delivery` 候选结构。

### 8.1 LLM-3 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "role_evi_cards": "{{P1.role_evi_cards}}",
  "price_evi_cards": "{{P1.price_evi_cards}}"
}
```

### 8.2 LLM-3 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "content_delivery_profile": {
    "preferred_content_formats": ["真实测评", "场景演示", "直播讲解"],
    "trust_triggers": ["价格透明", "真实评价", "售后保障"],
    "avoid_content": ["高压促单", "无证据高客单种草"],
    "channel_handoff": "短视频负责场景种草和知识解释，泛货架搜索承接显性需求，直播间负责价格解释、信任补强和实时答疑。",
    "content_style_preference": ["强场景演示", "价格对比", "真实试用"],
    "anchor_dependency": {
      "level": "中",
      "reason": "直播间转化存在，但并非唯一购买路径。"
    },
    "confidence": 0.68,
    "evidence": ["证据1", "证据2"]
  }
}
```

### 8.3 LLM-3 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的“内容触达与场域偏好推理节点”。你的任务是基于内容行为、主播/直播信任、场域购买、正向互动和价格证据，判断这个用户更适合用什么内容形式、主播讲解方式、信任触发点和场域承接链路触达，并输出严格 JSON。

你只负责触达方式判断，不负责生成兴趣场景，不负责生成候选商品方向，不负责判断未满足类目。你必须区分“内容兴趣”和“电商意图”：仅有短视频长停留或完播，不代表用户一定会购买；只有搜索、商品点击、商详、加购、订单、直播间商品点击或场域成交跟进，才是更强电商意图证据。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "role_evi_cards": {{P1.role_evi_cards}},
  "price_evi_cards": {{P1.price_evi_cards}}
}

【推理目标】
第一，输出 preferred_content_formats，说明用户更容易接受的内容形态，例如真实测评、场景演示、教程清单、材质讲解、功效解释、价格对比、直播讲解、达人口碑、清单式推荐。
第二，输出 trust_triggers，说明能提升信任和转化意愿的信息，例如价格透明、真实评价、售后保障、认证背书、主播专业讲解、材质证明、对比测评、低试错承诺。
第三，输出 avoid_content，说明应避免的内容方式，例如夸大功效、只讲低价不解释价值、高压促单、无证据高客单种草、强人设背书但缺少商品信息。
第四，输出 channel_handoff，说明短视频、直播间、泛货架搜索、商城、店铺页等场域如何分工承接。
第五，输出 anchor_dependency，判断用户对主播或直播间的依赖强弱。

【场域判断规则】
1. 如果直播间支付 GMV 占比高、直播间商品点击和停留强、主播信任证据强，可以提高直播承接优先级。
2. 如果搜索、商城、泛货架订单占比高，应强调显性需求由搜索/商城承接，短视频或直播负责种草和信任补强。
3. 如果短视频内容正向强但缺少商品点击/订单，应输出“短视频低频种草验证”，不能直接判定强转化。
4. 如果用户价格敏感或退款风险高，应强化价格透明、售后保障、真实评价和低试错承诺。
5. 如果证据稀疏，应输出更通用、保守的触达画像，并降低 confidence。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。preferred_content_formats、trust_triggers、avoid_content 各输出 2 到 6 条。anchor_dependency.level 只能输出 高、中、低、未知。confidence 必须是 0 到 1 的数字。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "content_delivery_profile": {
    "preferred_content_formats": ["string"],
    "trust_triggers": ["string"],
    "avoid_content": ["string"],
    "channel_handoff": "string",
    "content_style_preference": ["string"],
    "anchor_dependency": {
      "level": "高/中/低/未知",
      "reason": "string"
    },
    "confidence": 0.0,
    "evidence": ["string"]
  }
}

如果输入证据整体为空或无法理解，输出 inputValidation=false，error_code=ERR_LLM3_INPUT_EMPTY，error_text=内容触达推理输入为空或无法理解。
```

## 九、LLM-4：负向信号与风险雷达

LLM-4 是风险约束节点。它只进入 A1，不进入 LLM-5。它的作用是在最终阶段约束候选商品、价格带、触达策略和置信度，而不是提前删除潜在兴趣。

### 9.1 LLM-4 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "risk_evi_cards": "{{P1.risk_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "price_evi_cards": "{{P1.price_evi_cards}}"
}
```

### 9.2 LLM-4 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "negative_signal_radar": [
    {
      "signal_id": "risk_001",
      "signal_type": "content_only",
      "risk_code": "content_only",
      "risk_label": "内容-only 风险",
      "severity": "medium",
      "affected_objects": ["cand_003"],
      "evidence": ["证据1"],
      "risk_reasoning": "该类目主要来自内容停留，缺少搜索、商详或订单承接。",
      "mitigation_hint": "只允许低门槛试探，不建议高客单商品。"
    }
  ]
}
```

### 9.3 LLM-4 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的“负向信号与风险雷达节点”。你的任务是基于退款、负反馈、快速滑走、正负校正、内容-only、证据稀疏、类目噪声和价格上探风险，输出用于最终推荐约束的风险雷达 JSON。

你只负责识别风险，不负责删除兴趣候选，不负责生成兴趣场景，不负责生成商品方向。负向信号不是“绝对不感兴趣”的同义词，必须结合正向校正、内容场景、类目和时间窗判断。你的输出只进入最终 A1 装配与风险约束，不进入 LLM-5。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "risk_evi_cards": {{P1.risk_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "price_evi_cards": {{P1.price_evi_cards}}
}

【风险类型 taxonomy】
risk_code 和 signal_type 只能从以下枚举中选择：
- sparse_evidence：证据稀疏风险。行为少、时间跨度短、缺少稳定证据。
- content_only：内容-only 风险。只有内容消费，缺少搜索、点击、商详、加购或订单。
- refund_negative：退款/负反馈风险。退款、售后、取消或负反馈集中。
- price_overreach：价格上探风险。推荐价格显著高于历史承受力或类目锚点。
- category_noise：类目噪声风险。行为可能由误点、偶然浏览或泛内容导致。
- stale_interest：兴趣过期风险。历史兴趣近期无行为且缺少周期唤醒证据。
- privacy_sensitive_inference：敏感推断风险。婚育、收入、健康、家庭结构等被无证据推断。

【严重度规则】
severity 只能输出 low、medium、medium_high、high。
1. high：风险直接影响推荐是否应该强触达，例如高退款、高投诉、强负反馈、明显高价过推或敏感推断。
2. medium_high：风险会显著影响价格带、频次、场域或商品方向。
3. medium：风险需要约束但不必完全阻断。
4. low：风险较轻，只作为提示。

【判断规则】
1. 快速滑走或短停留不等于绝对不感兴趣，应结合正向互动、搜索、商详、订单和内容垂类校正。
2. 退款风险应尽量指向具体类目、商品方向、价格带或售后类型，不要泛化为“用户不好服务”。
3. 内容-only 风险主要约束价格带和复杂决策商品，不应完全删除低门槛探索。
4. 高价过推风险必须结合历史价格锚点、类目价格和消费能力证据判断。
5. 敏感推断风险用于阻止无证据推断婚育、收入、健康、身体、家庭结构和身份标签。
6. 如果没有明显负向信号，也要输出空数组，不要编造风险。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。negative_signal_radar 最多输出 8 条，按 severity 和影响范围降序排列。affected_objects 可以填写候选 ID、类目名、场景名、角色 code、价格带或“global”。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "negative_signal_radar": [
    {
      "signal_id": "risk_001",
      "signal_type": "sparse_evidence/content_only/refund_negative/price_overreach/category_noise/stale_interest/privacy_sensitive_inference",
      "risk_code": "sparse_evidence/content_only/refund_negative/price_overreach/category_noise/stale_interest/privacy_sensitive_inference",
      "risk_label": "string",
      "severity": "low/medium/medium_high/high",
      "affected_objects": ["string"],
      "evidence": ["string"],
      "risk_reasoning": "string",
      "mitigation_hint": "string"
    }
  ]
}

如果输入证据整体为空或无法理解，输出 inputValidation=true，error_code=""，error_text=""，negative_signal_radar=[]，不要报错，因为没有风险证据时可以正常进入最终装配。
```

## 十、LLM-5：兴趣场景、兴趣簇、兴趣类目泛化归并

LLM-5 是本 Workflow 的核心推理节点。它把 LLM-2 的兴趣候选、LLM-1 的消费画像和 P1 的正向证据，归并为 V9 所需的 `interest_scene_graph` 骨架。这里的兴趣场景不固定枚举，但必须严格限制数量、证据要求、泛化边界、权重排序和类目白名单。

> 兴趣场景回答“用户为什么需要”；兴趣簇回答“用什么供给组合承接”；兴趣类目回答“落到平台哪些类目”。三者不能混同。

### 10.1 LLM-5 输入

```json
{
  "persona_profile": "{{LLM1.persona_profile}}",
  "consumption_profile": "{{LLM1.consumption_profile}}",
  "role_profile": "{{LLM1.role_profile}}",
  "spend_power_profile": "{{LLM1.spend_power_profile}}",
  "interest_candidates": "{{LLM2.interest_candidates}}",
  "category_intent_cards": "{{LLM2.category_intent_cards}}",
  "evi_digest": "{{P1.evi_digest}}",
  "interest_evi_cards": "{{P1.interest_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "category_constraint_cards": "{{P1.category_constraint_cards}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "run_config_norm": "{{P0.run_config_norm}}"
}
```

### 10.2 LLM-5 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_scene_graph_skel": [
    {
      "scene_id": "S001",
      "scene_name": "夏季通勤轻薄穿搭补给",
      "need_summary": "在高温通勤或日常外出中，以低门槛基础款改善穿着舒适度。",
      "scene_reason": "近期搜索与点击集中在夏季袜子和基础服饰，需求更像季节性舒适穿搭补给，而不是泛服饰兴趣。",
      "linked_roles": ["ROLE_PRICE_OPTIMIZER", "ROLE_SELF_USE_PRAGMATIC"],
      "source_role_codes": ["price_optimizer", "self_use_pragmatic"],
      "priority": "P0",
      "scene_weight": 0.86,
      "confidence": 0.82,
      "evidence": ["证据1", "证据2"],
      "interest_clusters": [
        {
          "cluster_id": "C001",
          "cluster_name": "脚部舒适与基础服饰补给",
          "demand_summary": "承接夏季通勤舒适穿搭需求。",
          "cluster_goal": "用低门槛、强功能、易复购的基础服饰类商品承接。",
          "cluster_weight": 0.84,
          "generalization_rule": "同功能泛化",
          "supply_boundary": ["薄款短袜", "透气内衣", "基础 T 恤"],
          "unmet_interest_categories_skel": [
            {
              "category_id": "CAT_S001_C001_001",
              "category_name": "薄款短袜",
              "category_path": {
                "category_level_1_name": "服饰/鞋靴",
                "category_level_2_name": "服饰",
                "category_level_3_name": "薄款短袜"
              },
              "interest_type": "short_term_interest",
              "linked_roles": ["ROLE_PRICE_OPTIMIZER"],
              "unmet_reason": "近期搜索和商详行为显示短期需求，但尚未形成稳定购买闭环。",
              "mapping_confidence": 0.86,
              "evidence_level": "direct"
            }
          ],
          "do_not_expand_to": ["高客单奢侈服饰", "无证据的全套潮流穿搭", "跨季厚重服饰"]
        }
      ]
    }
  ]
}
```

### 10.3 LLM-5 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的“兴趣场景、兴趣簇、兴趣类目泛化归并节点”。你的任务是把消费画像、兴趣候选、正向证据和类目白名单，归并为用户未来推荐承接所需的兴趣场景图谱骨架，并输出严格 JSON。

你是本 Workflow 的核心需求发现节点。你必须区分三个层级：
1. 兴趣场景：回答用户在什么生活、任务、关系、时间窗口或内容语境下产生需求。场景名称必须是需求语境，不能只是类目名。
2. 兴趣簇：回答该场景可由哪些供给集合承接。兴趣簇是供给组合，不是抽象标签。
3. 未满足兴趣类目：回答具体落到平台哪些类目、属于什么兴趣类型、为什么可能未被充分满足。

你不能读取或使用负向风险节点的结果。负向风险由 A1 在最终阶段合并。你不能因为滑走、退款或负反馈提前删除潜在兴趣候选；但你可以基于正向证据强弱调整 confidence。

【输入】
{
  "persona_profile": {{LLM1.persona_profile}},
  "consumption_profile": {{LLM1.consumption_profile}},
  "role_profile": {{LLM1.role_profile}},
  "spend_power_profile": {{LLM1.spend_power_profile}},
  "interest_candidates": {{LLM2.interest_candidates}},
  "category_intent_cards": {{LLM2.category_intent_cards}},
  "evi_digest": {{P1.evi_digest}},
  "interest_evi_cards": {{P1.interest_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "category_constraint_cards": {{P1.category_constraint_cards}},
  "cat_l12_map": {{P0.cat_l12_map}},
  "run_config_norm": {{P0.run_config_norm}}
}

【数量约束】
1. interest_scene_graph_skel 最多输出 3 个核心兴趣场景，按 scene_weight 降序排列。
2. 每个场景最多输出 3 个兴趣簇，按 cluster_weight 降序排列。
3. 每个兴趣簇最多输出 5 个 unmet_interest_categories_skel，按 mapping_confidence 和供给承接价值排序。
4. 不要为了覆盖而凑场景、凑簇或堆类目。证据不足时可以少输出。

【场景生成规则】
1. scene_name 必须体现任务、目标、关系、时间窗口、使用情境或内容探索语境，不能直接输出“服饰”“食品”“宠物”“美妆”这类类目名。
2. scene_name 不得包含搜索、点击、浏览、商详、加购、成交、购买、下单、强推、召回、风险、疲劳、未转化等行为漏斗词或策略词。
3. 每个场景至少需要 1 条强证据，或 2 条弱证据互相印证。
4. 每个场景必须输出 need_summary 和 scene_reason。need_summary 面向需求解释，scene_reason 面向为什么这样归并。
5. priority 只能输出 P0、P1、P2、P3。P0 表示最优先承接，P3 表示低优先级试探。

【泛化规则】
你只允许以下五类一跳泛化：
1. 同功能泛化：与原始证据解决同一功能问题。例如从“短袜”到“薄款袜、透气内衣、基础 T 恤”。
2. 互补商品泛化：与原商品存在明确搭配或任务互补。例如从“露营垫”到“收纳袋、防晒帽、便携水杯”。
3. 周期复购泛化：有明确消耗周期或历史复购。例如从“宠物主粮”到“猫砂、宠物清洁”。
4. 场景任务泛化：存在明确任务，如开学、旅行、搬家、装修、节令准备。例如从“书包”到“姓名贴、文具、收纳袋”。
5. 内容试探泛化：只有内容兴趣时，只能低门槛探索。例如从“露营视频”到“野餐垫、小收纳、入门水杯”。

禁止二跳或过度泛化。不得从“短袜”扩到“全套潮流穿搭”或“奢侈品”；不得从“水果”扩到“全部生鲜高客单礼盒”；不得从内容浏览直接扩到高客单复杂决策商品。

【兴趣类型映射】
未满足兴趣类目层的 interest_type 必须使用 V9 最终枚举，只能从以下五项选择：
- long_term_interest：长期兴趣。用户在较长时间内持续表现出的稳定类目兴趣。
- short_term_interest：短期兴趣。近期行为快速升温但持续性尚不确定。
- potential_interest_probe：潜在兴趣探索。显性行为不足，但由角色、场景或相邻类目推理出的探索类目。
- repeat_purchase_interest：复购型兴趣。由周期性消耗、补货、复购行为推断。
- seasonal_interest：季节/节点兴趣。与季节、节日、节点或外部时令强相关。

如果来自 LLM-2 的 interest_type 是 long_term，映射为 long_term_interest；short_term 映射为 short_term_interest；silent_reactivatable 可视证据映射为 long_term_interest 或 potential_interest_probe；periodic_repurchase 映射为 repeat_purchase_interest；potential_exploratory 映射为 potential_interest_probe。若存在明确季节、节日、换季或节点时间窗口，优先映射为 seasonal_interest。

【类目约束】
1. category_path.category_level_1_name 必须是 cat_l12_map 的 key。
2. category_path.category_level_2_name 必须属于 cat_l12_map[category_level_1_name]。
3. category_path.category_level_3_name 必须是商品供给粒度，不能是品牌词、场景词、内容垂类、泛需求词或过泛词。
4. category_id 需按 CAT_S场景序号_C簇序号_类目序号 生成，例如 CAT_S001_C001_001。
5. 如果 L1/L2 无法合法映射，宁可不输出该类目，不要硬编。

【消费角色 ID 映射】
linked_roles 必须使用 V9 风格 role_id。请按以下规则从 source_role_codes 映射：
- self_use_pragmatic -> ROLE_SELF_USE_PRAGMATIC
- self_pleasing -> ROLE_SELF_IMPROVEMENT
- family_buyer -> ROLE_FAMILY_BUYER
- caregiver -> ROLE_CAREGIVER
- gift_buyer -> ROLE_GIFT_SOCIAL
- hobby_investor -> ROLE_HOBBY_INVESTMENT
- trend_follower -> ROLE_CONTENT_SEEDED
- price_optimizer -> ROLE_PRICE_OPTIMIZER
- quality_upgrader -> ROLE_QUALITY_UPGRADER
- uncertain_sparse -> ROLE_UNCERTAIN_SPARSE

【边界约束】
每个 interest_cluster 必须输出 do_not_expand_to，说明不能扩展到哪些方向。do_not_expand_to 应具体，例如“高客单奢侈服饰”“无证据的全套家电升级”“跨品类保健治疗承诺”，不要只写“不要过度泛化”。

【权重和置信度】
scene_weight、cluster_weight、confidence、mapping_confidence 均为 0 到 1 的数字。权重应由证据强度、近期性、交易强度、搜索强度、角色匹配、内容迁移风险共同决定。排序必须与权重一致。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。不要输出最终 V9 JSON；你只输出 interest_scene_graph_skel 骨架。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_scene_graph_skel": [
    {
      "scene_id": "S001",
      "scene_name": "string",
      "need_summary": "string",
      "scene_reason": "string",
      "linked_roles": ["ROLE_XXX"],
      "source_role_codes": ["string"],
      "priority": "P0/P1/P2/P3",
      "scene_weight": 0.0,
      "confidence": 0.0,
      "evidence": ["string"],
      "interest_clusters": [
        {
          "cluster_id": "C001",
          "cluster_name": "string",
          "demand_summary": "string",
          "cluster_goal": "string",
          "cluster_weight": 0.0,
          "generalization_rule": "同功能泛化/互补商品泛化/周期复购泛化/场景任务泛化/内容试探泛化/直接证据承接",
          "supply_boundary": ["string"],
          "unmet_interest_categories_skel": [
            {
              "category_id": "CAT_S001_C001_001",
              "category_name": "string",
              "category_path": {
                "category_level_1_name": "string",
                "category_level_2_name": "string",
                "category_level_3_name": "string"
              },
              "interest_type": "long_term_interest/short_term_interest/potential_interest_probe/repeat_purchase_interest/seasonal_interest",
              "linked_roles": ["ROLE_XXX"],
              "unmet_reason": "string",
              "mapping_confidence": 0.0,
              "evidence_level": "direct/indirect/inferred/content_probe"
            }
          ],
          "do_not_expand_to": ["string"]
        }
      ]
    }
  ]
}

如果正向兴趣证据整体为空或无法形成任何合法类目映射，输出 inputValidation=true，error_code=""，error_text=""，interest_scene_graph_skel=[]，不要编造场景。
```

## 十一、Batch：按兴趣场景拆分

Batch 节点将 `interest_scene_graph_skel` 按场景拆成单条输入，传给 LLM-6 并行补全候选商品方向。它不改变内容，只做数组拆分、上下文携带和索引记录。

### 11.1 Batch 输入

```json
{
  "interest_scene_graph_skel": "{{LLM5.interest_scene_graph_skel}}",
  "spend_power_profile": "{{LLM1.spend_power_profile}}",
  "persona_profile": "{{LLM1.persona_profile}}",
  "consumption_profile": "{{LLM1.consumption_profile}}",
  "price_evi_cards": "{{P1.price_evi_cards}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "run_config_norm": "{{P0.run_config_norm}}"
}
```

### 11.2 Batch 输出给 LLM-6 的单条结构

```json
{
  "batch_index": 0,
  "scene_item": {},
  "spend_power_profile": {},
  "persona_profile": {},
  "consumption_profile": {},
  "price_evi_cards": [],
  "cat_l12_map": {},
  "max_product_directions_per_scene": 6
}
```

### 11.3 Batch 工程规则

| 规则 | 说明 |
| --- | --- |
| 场景数截断 | 如果 LLM-5 输出超过 3 个场景，按 `scene_weight` 降序取 Top 3，并记录 `batch_qc.truncated=true`。 |
| 顺序保持 | 每条输出保留 `batch_index` 和 `scene_id`，便于 A1 回填。 |
| 空数组处理 | 如果 `interest_scene_graph_skel=[]`，Batch 输出空数组，LLM-6 不执行或执行 0 次。 |
| 上下文携带 | 每条单场景输入都携带消费能力、消费人格、消费角色、价格证据和类目白名单。 |

## 十二、LLM-6：单场景候选商品方向补全

LLM-6 将单个兴趣场景下的兴趣簇补全为可推荐商品方向、推荐价格带、卖点逻辑、内容触发和风险说明。它不重新判断场景，不新增超出 LLM-5 边界的类目。

### 12.1 LLM-6 输入

```json
{
  "batch_index": "{{Batch.batch_index}}",
  "scene_item": "{{Batch.scene_item}}",
  "spend_power_profile": "{{Batch.spend_power_profile}}",
  "persona_profile": "{{Batch.persona_profile}}",
  "consumption_profile": "{{Batch.consumption_profile}}",
  "price_evi_cards": "{{Batch.price_evi_cards}}",
  "cat_l12_map": "{{Batch.cat_l12_map}}"
}
```

### 12.2 LLM-6 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "scene_id": "S001",
  "product_direction_cards": [
    {
      "product_inference_id": "PI_S001_001",
      "target_cluster_id": "C001",
      "product_direction": "夏季薄款短袜与基础通勤袜",
      "target_category": {
        "category_id": "CAT_S001_C001_001",
        "category_name": "薄款短袜",
        "category_path": "服饰/鞋靴 > 服饰 > 薄款短袜"
      },
      "target_role": "ROLE_PRICE_OPTIMIZER",
      "recommended_price_band": {
        "price_level": "value",
        "typical_range": "19-59元",
        "band_meaning": "低到中位价格带，适合以组合装和优惠承接。"
      },
      "price_band_label": "value",
      "price_min": 19,
      "price_max": 59,
      "price_anchor_type": "历史低中客单 + 类目保守估算",
      "selling_point_logic": "强调透气、舒适、组合装和优惠确定性。",
      "content_trigger": "短视频展示夏季通勤穿着场景，直播间补充价格与材质解释。",
      "reasoning": "与近期搜索点击一致，低门槛承接短期需求。",
      "risk_note": "不建议直接推荐高客单品牌服饰。",
      "confidence": 0.78
    }
  ]
}
```

### 12.3 LLM-6 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的“单场景候选商品方向补全节点”。你的任务是基于一个已确定的兴趣场景、该场景下的兴趣簇和未满足兴趣类目，补全可推荐商品方向、类目级当前消费力价格带、卖点逻辑、内容触发方式和推理说明，并输出严格 JSON。

你不能重新判断场景，不能改写 scene_name，不能新增超出 scene_item.interest_clusters[].supply_boundary 和 unmet_interest_categories_skel 的类目，不能把局部高客单能力泛化到所有类目。你只能在 LLM-5 给定的场景、簇和类目边界内补全商品方向。

【输入】
{
  "batch_index": {{Batch.batch_index}},
  "scene_item": {{Batch.scene_item}},
  "spend_power_profile": {{Batch.spend_power_profile}},
  "persona_profile": {{Batch.persona_profile}},
  "consumption_profile": {{Batch.consumption_profile}},
  "price_evi_cards": {{Batch.price_evi_cards}},
  "cat_l12_map": {{Batch.cat_l12_map}}
}

【价格带推理优先级】
价格带不是全局画像字段，而是落在未满足兴趣类目和候选商品方向上的策略判断。你必须按以下优先级推理：
1. 历史价格锚点优先：如果该类目或相近类目存在历史均价、P90、最高支付、最近订单金额，优先使用。
2. 类目价格带其次：如果无历史锚点，使用平台类目常识或类目价格分位做保守估计，并说明 price_anchor_type。
3. 消费能力第三：低消费力偏 entry，谨慎型中低消费力偏 entry/value，中等消费力偏 value/低 quality，品质型中高消费力偏 quality，高消费力可承接 quality/premium。
4. 消费人格修正：精明理性或价格优化型应下调上探；品质升级型只能在有证据类目中允许上探。
5. 风险保守修正：如果证据稀疏、内容-only、价格证据弱、类目迁移远，应选择更保守价格带，并在 risk_note 中说明。

【价格层级枚举】
recommended_price_band.price_level 只能输出以下值之一：
- entry：低门槛、低试错成本价格带。
- value：性价比、中低价格带或组合装价格带。
- quality：品质款、中高价格带或有明确价值解释的升级款。
- premium：高客单、高品质、品牌化或专业化价格带，仅在强证据支持时使用。
- high_but_role_specific：局部高客单，但只在特定角色、类目或场景中成立。

price_band_label 与 price_level 保持一致，除非需要兼容历史系统，也应使用 entry/value/quality/premium/high_but_role_specific。

【商品方向生成规则】
1. product_direction 是商品方向，不是具体 SKU，不要输出品牌名或商品 ID。
2. 每个兴趣簇建议输出 3 到 5 个商品方向；单个场景最多输出 6 个商品方向。
3. target_category 必须来自 scene_item 中已有 unmet_interest_categories_skel，不得新增 L1/L2/L3。
4. target_role 必须来自该类目的 linked_roles 或场景 linked_roles。
5. selling_point_logic 必须说明该商品方向应突出什么卖点才能匹配用户需求。
6. content_trigger 必须说明适合用什么内容表达激活用户，例如真实试用、场景演示、对比测评、材质说明、价格透明、主播讲解等。
7. reasoning 必须解释为什么该商品方向适合当前用户、场景、角色和供给簇。
8. risk_note 必须说明不宜如何过推、价格上探边界或证据不足点。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。所有 confidence 必须是 0 到 1 的数字。price_min 和 price_max 必须是数字；如果无法给出明确数字，使用保守估计，不要输出 null。typical_range 必须使用“X-Y元”格式。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "scene_id": "S001",
  "product_direction_cards": [
    {
      "product_inference_id": "PI_S001_001",
      "target_cluster_id": "C001",
      "product_direction": "string",
      "target_category": {
        "category_id": "string",
        "category_name": "string",
        "category_path": "一级类目 > 二级类目 > 三级类目"
      },
      "target_role": "ROLE_XXX",
      "recommended_price_band": {
        "price_level": "entry/value/quality/premium/high_but_role_specific",
        "typical_range": "X-Y元",
        "band_meaning": "string"
      },
      "price_band_label": "entry/value/quality/premium/high_but_role_specific",
      "price_min": 0,
      "price_max": 0,
      "price_anchor_type": "历史价格锚点/相近类目锚点/类目保守估算/消费能力默认/证据稀疏保守估算",
      "selling_point_logic": "string",
      "content_trigger": "string",
      "reasoning": "string",
      "risk_note": "string",
      "confidence": 0.0
    }
  ]
}

如果 scene_item 为空或没有合法 unmet_interest_categories_skel，输出 inputValidation=false，error_code=ERR_LLM6_SCENE_EMPTY，error_text=单场景输入为空或缺少合法类目，product_direction_cards=[]。
```

## 十三、A1：最终装配与 Schema 质检

A1 是确定性代码节点，负责把所有上游结果装配为 V9 JSON，并执行可程序化检查。A1 不调用 LLM 修复；质检失败时返回结构化错误，方便定位是 P0、P1、LLM-5 还是 LLM-6 的问题。

### 13.1 A1 输入

```json
{
  "std_user": "{{P0.std_user}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "persona_profile": "{{LLM1.persona_profile}}",
  "consumption_profile": "{{LLM1.consumption_profile}}",
  "role_profile": "{{LLM1.role_profile}}",
  "spend_power_profile": "{{LLM1.spend_power_profile}}",
  "content_delivery_profile": "{{LLM3.content_delivery_profile}}",
  "negative_signal_radar": "{{LLM4.negative_signal_radar}}",
  "interest_scene_graph_skel": "{{LLM5.interest_scene_graph_skel}}",
  "product_direction_cards_by_scene": "{{LLM6.product_direction_cards}}"
}
```

### 13.2 A1 成功输出：最终 V9 JSON

```json
{
  "uid": "user_xxx",
  "consumption_interest_profile": {
    "consumption_persona": {
      "persona_name": "审慎型品质实用派",
      "persona_summary": "...",
      "persona_tags": {
        "vals_layer": "第二层-效率实用与家庭责任",
        "vals_type": "精明理性型",
        "vals_tribe": "精明消费族"
      },
      "core_traits": ["..."],
      "confidence": 0.72
    },
    "dominant_role_summary": "...",
    "consumption_roles": []
  },
  "interest_scene_graph": [],
  "content_anchor_delivery": {},
  "negative_signal_radar": []
}
```

### 13.3 A1 装配映射

| V9 字段 | 来源 | 装配规则 |
| --- | --- | --- |
| `uid` | `P0.std_user.user_id` | 只保留用户 ID，不暴露调试链路。 |
| `consumption_interest_profile.consumption_persona` | `LLM1.persona_profile` | 直接映射 `persona_name`、`persona_summary`、`persona_tags`、`core_traits`、`confidence`。 |
| `consumption_interest_profile.dominant_role_summary` | `LLM1.consumption_profile.dominant_role_summary` | 若为空，由 A1 根据 Top roles 拼接一句话。 |
| `consumption_interest_profile.consumption_roles[]` | `LLM1.consumption_profile.role_mix[]` | 转换 role_id、role_name、role_target、role_motivation、decision_focus、price_sensitivity、trust_requirement、confidence。 |
| `interest_scene_graph[]` | `LLM5.interest_scene_graph_skel` | 最多 3 个，按 `scene_weight` 降序；字段名转换为 V9 的 `need_summary`、`priority` 等。 |
| `interest_clusters[]` | `LLM5.interest_clusters[]` | 每场景最多 3 个，按 `cluster_weight` 降序。 |
| `unmet_interest_categories[]` | `LLM5.unmet_interest_categories_skel[]` + LLM-6 价格带 | 每簇最多 5 个；补齐 `current_consumption_price_band`。 |
| `candidate_product_inferences[]` | `LLM6.product_direction_cards[]` | 按 cluster 归并，填入商品方向、目标类目、推荐价格带、卖点逻辑、内容触发、推理说明。 |
| `content_anchor_delivery` | `LLM3.content_delivery_profile` | 映射偏好内容形式、信任触发点、应避免内容、场域承接链路和置信度。 |
| `negative_signal_radar[]` | `LLM4.negative_signal_radar` | 必须进入最终结果，不参与 LLM-5。 |

### 13.4 role_code 到 V9 role_id 映射

| LLM-1 `role_code` | V9 `role_id` | V9 `role_name` |
| --- | --- | --- |
| `self_use_pragmatic` | `ROLE_SELF_USE_PRAGMATIC` | 自用实用型 |
| `self_pleasing` | `ROLE_SELF_IMPROVEMENT` | 悦己改善型 |
| `family_buyer` | `ROLE_FAMILY_BUYER` | 家庭采购型 |
| `caregiver` | `ROLE_CAREGIVER` | 照护责任型 |
| `gift_buyer` | `ROLE_GIFT_SOCIAL` | 礼赠社交型 |
| `hobby_investor` | `ROLE_HOBBY_INVESTMENT` | 兴趣投入型 |
| `trend_follower` | `ROLE_CONTENT_SEEDED` | 内容种草型 |
| `price_optimizer` | `ROLE_PRICE_OPTIMIZER` | 价格优化型 |
| `quality_upgrader` | `ROLE_QUALITY_UPGRADER` | 品质升级型 |
| `uncertain_sparse` | `ROLE_UNCERTAIN_SPARSE` | 证据稀疏待观察型 |

### 13.5 interest_type 映射与校验

A1 最终只能保留 V9 枚举：`long_term_interest`、`short_term_interest`、`potential_interest_probe`、`repeat_purchase_interest`、`seasonal_interest`。如果 LLM-5 已按 V9 枚举输出，则直接保留；如果出现 LLM-2 旧枚举，应按如下规则转换，无法转换时报错。

| 过程枚举 | V9 枚举 | 说明 |
| --- | --- | --- |
| `long_term` | `long_term_interest` | 长期稳定类目兴趣。 |
| `short_term` | `short_term_interest` | 近期升温类目兴趣。 |
| `silent_reactivatable` | `long_term_interest` 或 `potential_interest_probe` | 有历史强证据时用长期兴趣；证据弱时用潜在探索。 |
| `periodic_repurchase` | `repeat_purchase_interest` | 周期/复购型兴趣。 |
| `potential_exploratory` | `potential_interest_probe` | 探索/潜在新兴趣。 |
| 明确季节/节日/节点 | `seasonal_interest` | 节点属性优先于普通短期兴趣。 |

### 13.6 A1 质检规则

| 质检项 | 校验规则 | 失败处理 |
| --- | --- | --- |
| Schema 完整性 | V9 必填字段存在，类型正确 | `ERR_SCHEMA_MISSING` 或 `ERR_SCHEMA_TYPE`。 |
| UID | `uid` 非空字符串 | `ERR_UID_MISSING`。 |
| 场景数量 | `interest_scene_graph` 长度 ≤ 3 | 超出按权重截断并记录 `WARN_SCENE_TRUNCATED`；无法排序则 `ERR_SCENE_COUNT_INVALID`。 |
| 簇数量 | 每场景 `interest_clusters` 长度 ≤ 3 | 超出按 `cluster_weight` 截断并记录 warning。 |
| 类目数量 | 每簇 `unmet_interest_categories` 长度 ≤ 5 | 超出按置信度截断并记录 warning。 |
| 类目白名单 | L1/L2 必须来自 `cat_l12_map`，且 L2 隶属 L1 | `ERR_CAT_L12_INVALID`。 |
| L3 粒度 | L3 不能是品牌词、场景词、过泛词 | 标记 `WARN_CAT_L3_WEAK` 并下调置信度；严重时 `ERR_CAT_L3_INVALID`。 |
| 商品方向关联 | `candidate_product_inferences[].target_category` 必须能关联本簇类目或供给边界 | `ERR_PRODUCT_CATEGORY_UNLINKED`。 |
| 消费角色枚举 | role_code 必须来自 10 个角色 taxonomy | `ERR_ROLE_ENUM_INVALID`。 |
| China-VALS 标签 | `vals_layer`、`vals_type`、`vals_tribe` 必须命中受控集合 | `ERR_PERSONA_VALS_INVALID`。 |
| 消费能力枚举 | `spend_power_code/label` 必须匹配五档 | `ERR_SPEND_POWER_INVALID`。 |
| 场景质量 | `scene_name` 不得等同类目名，必须有 `need_summary` 和证据 | `ERR_SCENE_QUALITY_LOW` 或下调置信度。 |
| 泛化边界 | 每个 cluster 必须有 `supply_boundary` 和 `do_not_expand_to` | `ERR_SCENE_BOUNDARY_MISSING`。 |
| 负向风险合并 | LLM-4 风险必须进入最终 `negative_signal_radar`，空数组也合法 | 缺失字段时报 `ERR_RISK_MISSING`。 |
| 价格带合理性 | 类目价格带和商品推荐价格带必须有层级、范围和含义 | `ERR_PRICE_BAND_MISSING`。 |
| 敏感表达 | 不得出现外貌、真实年龄、收入阶层、身份刻板印象或贬损词 | `ERR_SENSITIVE_INFERENCE`。 |
| 置信度范围 | 所有 confidence 在 0—1 | 自动截断并记录 `WARN_CONF_ADJUSTED`。 |

### 13.7 A1 错误输出格式

```json
{
  "inputValidation": false,
  "error_code": "ERR_CAT_L12_INVALID",
  "error_text": "存在不在类目表白名单中的一级或二级类目。",
  "qc_report": {
    "failed_node": "A1",
    "failed_paths": ["interest_scene_graph[0].interest_clusters[0].unmet_interest_categories[1]"],
    "suggestion": "检查 LLM-5 的类目白名单约束，或检查 category_l12_file 是否完整。",
    "warnings": []
  }
}
```

## 十四、最终 End 节点输出策略

End 节点建议只输出 A1 的成功结果或错误结果，不再拼接上游调试字段。如果需要内部排障，可将 `qc_report`、`input_qc`、`batch_qc` 和上游节点原始输出写入日志系统，而不是进入前端画像主体。

| 场景 | End 输出 | 前端/调用方建议 |
| --- | --- | --- |
| A1 成功 | V9 JSON | 直接展示消费人格、消费角色、兴趣场景、兴趣簇、未满足类目、商品方向、内容触达和风险雷达。 |
| P0 输入失败 | 结构化错误 | 提示重新上传用户 JSON 或类目表，通常不扣费或进入异常处理。 |
| LLM 节点输入为空 | 对应节点错误或空结果 | 根据业务规则决定是否返回低置信画像或失败。 |
| A1 质检失败 | 结构化错误 + `qc_report` | 定位节点和字段路径，进入人工排障或自动重跑。 |

## 十五、最终 V9 输出完整骨架

以下是 A1 成功后最终对外输出的标准骨架。真实输出不得包含 Markdown、注释或过程字段。

```json
{
  "uid": "123456789",
  "consumption_interest_profile": {
    "consumption_persona": {
      "persona_name": "双轨价值分层型用户",
      "persona_summary": "该用户在日用服饰、食品和个护等类目中表现为价格敏感和实用补给，在部分有证据的高价值类目中存在品质或信任驱动的上探能力。推荐时应以真实试用、材质讲解、价格透明和售后确定性为核心，避免将局部高客单能力泛化为全局高消费力。",
      "persona_tags": {
        "vals_layer": "第二层-效率实用与家庭责任",
        "vals_type": "实用享乐混合型",
        "vals_tribe": "精明消费族"
      },
      "core_traits": [
        "日用和基础类目偏向性价比与低试错成本。",
        "有证据类目可进行有限品质上探。",
        "对真实测评、价格透明和售后保障较敏感。"
      ],
      "confidence": 0.82
    },
    "dominant_role_summary": "以自用实用和价格优化为主，存在局部悦己改善或内容种草辅助信号。",
    "consumption_roles": [
      {
        "role_id": "ROLE_PRICE_OPTIMIZER",
        "role_name": "价格优化型",
        "role_target": "给自己或家庭日常使用场景购买",
        "role_motivation": "用较低试错成本满足明确需求。",
        "decision_focus": ["性价比", "优惠确定性", "实用功能"],
        "price_sensitivity": "价格敏感度较高，适合 entry/value 价格带承接。",
        "trust_requirement": "需要价格透明、真实评价和低风险售后承诺。",
        "confidence": 0.78
      }
    ]
  },
  "interest_scene_graph": [
    {
      "scene_id": "S001",
      "scene_name": "夏季通勤轻薄穿搭补给",
      "linked_roles": ["ROLE_PRICE_OPTIMIZER", "ROLE_SELF_USE_PRAGMATIC"],
      "need_summary": "用户可能存在高温通勤或日常外出中的低门槛舒适穿搭需求。",
      "priority": "P0",
      "confidence": 0.82,
      "interest_clusters": [
        {
          "cluster_id": "C001",
          "cluster_name": "脚部舒适与基础服饰补给",
          "demand_summary": "围绕夏季通勤舒适穿搭，以低门槛、强功能、易复购基础服饰承接。",
          "cluster_weight": 0.84,
          "supply_boundary": ["薄款短袜", "透气内衣", "基础 T 恤"],
          "unmet_interest_categories": [
            {
              "category_id": "CAT_S001_C001_001",
              "category_name": "薄款短袜",
              "category_path": "服饰/鞋靴 > 服饰 > 薄款短袜",
              "interest_type": "short_term_interest",
              "linked_roles": ["ROLE_PRICE_OPTIMIZER"],
              "unmet_reason": "近期搜索和商详行为显示短期需求，但尚未形成稳定购买闭环。",
              "current_consumption_price_band": {
                "price_level": "value",
                "typical_range": "19-59元",
                "band_meaning": "低到中位价格带，适合以组合装和优惠承接。"
              },
              "confidence": 0.86
            }
          ],
          "candidate_product_inferences": [
            {
              "product_inference_id": "PI_S001_001",
              "product_direction": "夏季薄款短袜与基础通勤袜",
              "target_category": "CAT_S001_C001_001",
              "target_role": "ROLE_PRICE_OPTIMIZER",
              "recommended_price_band": "19-59元",
              "selling_point_logic": "强调透气、舒适、组合装和优惠确定性。",
              "content_trigger": "短视频展示夏季通勤穿着场景，直播间补充价格与材质解释。",
              "reasoning": "与近期搜索点击一致，低门槛承接短期需求。",
              "confidence": 0.78
            }
          ]
        }
      ]
    }
  ],
  "content_anchor_delivery": {
    "preferred_content_formats": ["真实测评", "场景演示", "价格对比", "材质讲解"],
    "trust_triggers": ["价格透明", "真实评价", "售后保障"],
    "avoid_content": ["夸大功效", "高压促单", "无证据高客单种草"],
    "channel_handoff": "短视频负责场景种草和知识解释，泛货架搜索承接显性需求，直播间负责价格解释、信任补强和实时答疑。",
    "confidence": 0.8
  },
  "negative_signal_radar": [
    {
      "signal_id": "risk_001",
      "signal_type": "price_overreach",
      "severity": "medium_high",
      "affected_objects": ["CAT_S001_C001_001", "PI_S001_001"],
      "risk_reasoning": "该类目历史价格锚点偏中低，不宜直接推荐高客单品牌款。",
      "mitigation_hint": "优先使用 entry/value 价格带验证兴趣，强信任证据出现后再逐步上探。"
    }
  ]
}
```

## 十六、落地质检清单

在真实搭建时，建议先用 5 到 10 个典型用户样本做链路冒烟测试，再进入批量评测。测试时不只看 JSON 是否能解析，还要看场景命名、类目映射、价格带、角色边界和风险是否符合业务常识。

| 检查项 | 合格标准 | 常见问题 |
| --- | --- | --- |
| JSON 可解析 | 所有 LLM 节点只输出合法 JSON | 模型输出 Markdown、注释或额外解释。 |
| 字段稳定 | 字段名与协议完全一致 | LLM 自创字段或遗漏 `error_code`、`error_text`。 |
| 类目白名单 | L1/L2 均命中 `cat_l12_map` | LLM 输出不存在的二级类目。 |
| 场景命名 | 场景是需求语境，不是类目名 | 输出“服饰兴趣”“食品兴趣”。 |
| 泛化边界 | 每个簇都有 `do_not_expand_to` | 商品方向扩得过远。 |
| 价格带 | 类目和商品方向均有价格层级、范围和含义 | 只输出“中等价格”，没有区间。 |
| 角色表达 | 多角色并存但不凑数 | 把所有用户都输出家庭、礼赠、悦己。 |
| 风险合并 | LLM-4 风险进入最终结果 | 负向信号丢失或提前进入 LLM-5。 |
| 敏感治理 | 不输出身份、收入、外貌、身体、婚育等推断 | “宝妈”“高收入”“身体差”等违规表达。 |
| 数量控制 | 场景 ≤ 3，簇 ≤ 3，类目 ≤ 5 | 输出过多弱场景，前端无法承接。 |

## 十七、推荐实施顺序

建议先按 P0、P1、LLM-1、LLM-2、LLM-5、Batch、LLM-6、A1 的主链路打通，再并行接入 LLM-3 和 LLM-4。这样可以优先验证“消费画像 → 兴趣候选 → 场景/簇/类目 → 商品方向 → V9 装配”的主干是否稳定。主干稳定后，再用 LLM-3 增强触达画像，用 LLM-4 增强负向风险边界。

| 阶段 | 目标 | 验收标准 |
| --- | --- | --- |
| 第一阶段 | 跑通 P0/P1/A1 基础结构 | 输入解析、类目表解析、错误输出和空结果处理稳定。 |
| 第二阶段 | 跑通 LLM-1/LLM-2/LLM-5 主推理 | 能生成合理消费人格、兴趣候选和场景骨架。 |
| 第三阶段 | 接入 Batch/LLM-6 | 每个场景能补全商品方向和价格带。 |
| 第四阶段 | 接入 LLM-3/LLM-4 | 内容触达和风险雷达能进入最终 V9。 |
| 第五阶段 | 批量样本评测 | JSON 合法率、类目合法率、敏感表达拦截率、人工可读性达到上线要求。 |

## 十八、结论

这版完整 Workflow 的关键价值在于把 V9 的**可展示画像结构**和平台侧的**可执行节点协议**打通。前端和策略同学看到的是消费人格、消费角色、兴趣场景、兴趣簇、未满足兴趣类目、候选商品方向、内容触达和负向风险；工程侧看到的是输入解析、证据压缩、并行 LLM 推理、场景 Batch、价格带补全和程序化质检。按照本文档搭建，可以在控制字段稳定性和类目合规性的同时，保留生成式推荐范式真正需要的开放式需求发现能力。
