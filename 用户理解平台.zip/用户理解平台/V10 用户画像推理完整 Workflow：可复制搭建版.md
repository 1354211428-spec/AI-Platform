# V10 用户画像推理完整 Workflow：可复制搭建版

作者：Manus AI（V9 原版）/ 优化修订：V10  
日期：2026-06-12  
适用场景：快手电商直播与短视频推荐中的用户理解、推荐策略白盒化、供给承接和巡检 Agent。

> **V10 版本说明**：本版本在 V9 基础上，针对实验运行中发现的 6 项推理质量问题进行定向修复，原文档（V9）保留归档，不做改动。本文档为优化后可直接替换使用的版本。

---

## V10 版本更新说明

| 问题编号 | 问题描述 | 涉及节点 | 改动类型 |
| --- | --- | --- | --- |
| 问题1 | 价格带绑定消费角色：未按消费角色与场景区分价格区间，仅按最高单笔价格锚定 | LLM-1、LLM-6 | Prompt 规则新增 |
| 问题2 | 兴趣场景内容泛化过宽：同一场景内兴趣簇语义不相关（如鲜果与换季衣物同场景） | LLM-5 | Prompt 规则新增 |
| 问题3 | 兴趣簇泛化不足：仅反映输入数据中已有商品，未基于场景需求主动推理供给集合 | LLM-5 | Prompt 规则强制化 |
| 问题4 | 兴趣商品泛化不足：每个兴趣簇仅推荐1个商品方向，选择过少 | LLM-6 | Prompt 规则强制化 |
| 问题5 | 兴趣簇间相似度高：相似兴趣簇未合并，边界模糊（如助眠隔音小件 vs 隔音耳部防护配件） | LLM-5 | Prompt 新增去重约束 |
| 问题6 | 商品与价格带链路断裂：价格带孤立在 LLM-6 输出，未与兴趣商品形成联通链路 | LLM-6、A1 | 输出结构说明 + 质检规则新增 |

---

## 一、设计定位与落地边界

本文档基于项目内《用户画像推理输出结构 V9：极简字段说明版》和《V9 用户画像推理简易 Workflow 清洁版：节点输入输出与 Prompt 设计说明》两份定稿文件，进一步补齐**可直接复制到 Workflow 平台搭建的完整节点方案**。本文不仅给出 DAG、每个节点的输入和输出协议，也给出每个 LLM 节点可直接粘贴使用的 Prompt，并补充 P0、P1、Batch、A1 等代码节点的工程实现要求。

本 Workflow 的目标不是复盘用户所有历史行为，而是把用户行为、交易、搜索、内容互动、场域偏好、类目约束和风险信号，推理成 V9 标准画像结果。最终输出只保留一个用户标识字段和四个画像主体模块：`consumption_interest_profile`、`interest_scene_graph`、`content_anchor_delivery` 和 `negative_signal_radar`。版本号、任务 ID、生成时间、模型信息、运行链路信息等工程元信息不进入画像主体，应由外部任务表或日志系统管理。

> **核心原则**：消费人格回答"这个用户整体上是什么样的消费风格"；消费角色回答"用户以什么身份和责任关系购买"；兴趣场景回答"用户在什么语境下产生需求"；兴趣簇回答"该场景可由什么供给集合承接"；未满足兴趣类目回答"具体可探索哪个类目以及它是什么兴趣类型"；候选商品方向回答"可以用什么商品方向进行推荐试探"。

| 设计项 | 定稿选择 | 说明 |
| --- | --- | --- |
| 最终输出结构 | 严格遵循 V9 极简字段 | 不输出过程字段、证据全文、模型链路和调试元信息。 |
| 类目约束方式 | Start 上传 L1/L2 类目文件，P0 解析为白名单 | 类目表不是 LLM 推理节点，L1/L2 必须受控。 |
| 兴趣场景 | 自由生成具体场景，但最多 3 个核心场景 | 场景名称必须表达需求语境，不能等同类目名。**（V10 新增：场景内兴趣簇须语义内聚，不得跨需求域混合归并）** |
| 兴趣类型 | 落在未满足兴趣类目层 | 同一场景或兴趣簇内可能同时包含长期、短期、复购、季节和潜在探索兴趣。 |
| 价格带 | 落在类目和商品方向层 | 不输出全局价格带，避免把局部支付能力泛化为全局消费能力。**（V10 新增：价格带须按消费角色差异化输出，不得以单一最高价锚定全部角色）** |
| 风险信号 | LLM-4 独立生成，只进入 A1 | 负向风险不进入 LLM-5，避免过早压制潜在兴趣发现。 |
| 最终质检 | A1 程序化校验 | 不设置 LLM 修复节点，失败时返回结构化错误。 |

---

## 二、完整 Workflow DAG

```mermaid
graph TD
    Start[Start: raw_user_json + category_l12_file + run_config] --> P0[Code P0: 输入解析、字段标准化、类目表解析]
    P0 --> P1[Code P1: 证据卡片构建]

    P1 --> L1[LLM-1: 消费人格、消费角色、消费能力推理]
    P1 --> L2[LLM-2: 兴趣候选与类目意图初判]
    P1 --> L3[LLM-3: 内容触达与场域偏好推理]
    P1 --> L4[LLM-4: 负向信号与风险雷达]

    L1 --> L5[LLM-5: 兴趣场景-兴趣簇-兴趣类目泛化归并]
    L2 --> L5
    P1 --> L5
    P0 --> L5

    L5 --> B1[Batch: 按兴趣场景拆分]
    B1 --> L6[LLM-6: 单场景候选商品方向补全]

    L1 --> A1[Code A1: 最终装配与 Schema 质检]
    L3 --> A1
    L4 --> A1
    L5 --> A1
    L6 --> A1
    P0 --> A1
    A1 --> End[End: V9 JSON 或结构化错误]
```

`LLM-1`、`LLM-2`、`LLM-3` 和 `LLM-4` 可并行执行。`LLM-5` 是核心归并节点，只读取正向证据、兴趣候选、消费画像和类目白名单，不读取负向风险，**只输出兴趣场景和兴趣簇两个层级，不再输出兴趣类目层**。`LLM-6` 通过 Batch 按兴趣场景并行执行，负责为每个兴趣簇推理多个兴趣商品以及每个商品对应的价格带，实现「兴趣场景→兴趣簇→兴趣商品→价格带」的完整链路。A1 是唯一的最终装配与程序化质检节点。

| 节点 | 类型 | 上游 | 核心职责 | 核心输出 |
| --- | --- | --- | --- | --- |
| Start | 输入 | 无 | 接收用户 JSON、类目文件和运行配置 | 原始输入 |
| P0 | Code | Start | 标准化输入、解析类目表、生成配置和输入质检 | `std_user`、`cat_l12_map`、`run_config_norm`、`input_qc` |
| P1 | Code | P0 | 将复杂输入压缩成 LLM 可消费证据卡片 | 六类证据卡片 |
| LLM-1 | LLM | P1 | 推理消费人格、多角色画像和消费能力（V10：增加角色维度价格弹性） | `persona_profile`、`consumption_profile`、`role_profile`、`spend_power_profile` |
| LLM-2 | LLM | P1、P0 | 推理兴趣候选和类目意图 | `interest_candidates`、`category_intent_cards` |
| LLM-3 | LLM | P1 | 推理内容、主播和场域触达画像 | `content_delivery_profile` |
| LLM-4 | LLM | P1 | 推理负向信号和推荐风险边界 | `negative_signal_radar` |
| LLM-5 | LLM | LLM-1、LLM-2、P1、P0 | 归并兴趣场景与兴趣簇骨架（V10：只输出场景层+簇层，增加场景内聚、簇泛化强制、簇去重约束，不再输出兴趣类目层） | `interest_scene_graph_skel` |
| Batch | Batch/Code | LLM-5、LLM-1、P1、P0 | 按场景拆分给 LLM-6 | 单场景输入数组 |
| LLM-6 | LLM | Batch | 为每个兴趣簇推理多个兴趣商品及对应价格带（V10：兴趣商品≥3强制、角色差异价格带、每商品一个价格带） | `interest_product_cards` |
| A1 | Code | 全部上游 | 装配 V9 JSON，做 Schema、枚举、数量、类目和风险质检（V10：新增价格带完整性质检） | V9 JSON 或结构化错误 |


---

## 三、Start 节点设计

Start 节点接收三个输入，其中 `raw_user_json` 和 `category_l12_file` 必填，`run_config` 可选。类目表作为独立文件输入，不混入用户行为 JSON，避免平台约束输入和用户行为输入混淆。

| 输入字段 | 类型 | 是否必填 | 说明 | 示例 |
| --- | --- | --- | --- | --- |
| `raw_user_json` | JSON 或字符串化 JSON | 是 | 单个用户的基础信息、交易、搜索、商品行为、内容互动、退款、负反馈、场域等原始字段。 | `mengchao测试数据_cleaned.json` |
| `category_l12_file` | 文件 | 是 | 平台一级/二级类目表，至少包含 `category_level_1_name` 和 `category_level_2_name`。 | CSV、TSV、XLSX |
| `run_config` | JSON | 否 | 控制数量上限和调试开关。 | `{"max_scenes":3,"max_clusters_per_scene":3,"max_categories_per_cluster":5,"debug":true}` |

建议 Start 输出给 P0 的结构如下。

```json
{
  "raw_user_json": "{{Start.raw_user_json}}",
  "category_l12_file": "{{Start.category_l12_file}}",
  "run_config": "{{Start.run_config}}"
}
```

---

## 四、P0：输入解析、字段标准化与类目表解析

P0 是确定性代码节点。它只做解析、归一、空值处理、字段兼容、类目表解析、配置归一和输入质检，不做人格、兴趣、场景、价格带或风险推理。

### 4.1 P0 输入

```json
{
  "raw_user_json": "{{Start.raw_user_json}}",
  "category_l12_file": "{{Start.category_l12_file}}",
  "run_config": "{{Start.run_config}}"
}
```

### 4.2 P0 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "std_user": {
    "user_id": "",
    "basic_profile": {},
    "item_behavior": [],
    "trade_profile": {},
    "trade_category_stats": [],
    "trade_brand_stats": [],
    "recent_orders": [],
    "negative_feedback": [],
    "signal_correction": [],
    "refund_profile": {},
    "content_behavior": [],
    "anchor_trust_profile": {},
    "field_preference": [],
    "ecom_comment_texts": [],
    "search_queries": []
  },
  "cat_l12_map": {
    "服饰/鞋靴": ["服饰", "鞋靴", "未知", "其他服饰/鞋靴"]
  },
  "cat_l1_list": ["服饰/鞋靴"],
  "cat_l2_pairs": [
    {
      "category_level_1_name": "服饰/鞋靴",
      "category_level_2_name": "服饰"
    }
  ],
  "cat_fallback_rules": {
    "unknown_l2_allowed": true,
    "other_l2_allowed": true,
    "l3_generated_by_llm": true
  },
  "run_config_norm": {
    "max_scenes": 3,
    "max_clusters_per_scene": 3,
    "max_categories_per_cluster": 5,
    "debug": true
  },
  "input_qc": {
    "missing_fields": [],
    "category_file_rows": 0,
    "category_duplicate_rows": 0,
    "sparse_modules": []
  }
}
```

### 4.3 P0 字段标准化规则

| 原始模块 | P0 标准对象 | 标准化要求 | 下游用途 |
| --- | --- | --- | --- |
| `user_id` 或 `uid` | `std_user.user_id` | 转成字符串；缺失时可使用外部任务 ID，但应标记 `missing_fields`。 | A1 输出 `uid`。 |
| `user_basic_info` | `basic_profile` | 城市、设备、U 分层、年龄段、性别等缺失统一为 `unknown`；只作为弱证据。 | LLM-1、LLM-5、LLM-6。 |
| `item_interaction` | `item_behavior[]` | 从字段名解析时间窗、行为类型、类目和值；过滤 0 值。 | LLM-2、LLM-5、LLM-6。 |
| `trade_data` | `trade_profile`、`trade_category_stats`、`recent_orders` | 保留订单时间、金额、商品名、L1/L2/L3、品牌、场域、退款状态和退款原因。 | LLM-1、LLM-2、LLM-5、LLM-6。 |
| `negative_feedback` | `negative_feedback[]` | 解析类目、内容垂类、负反馈类型和值；不得直接等同绝对不感兴趣。 | LLM-4、A1。 |
| `signal_correction` | `signal_correction[]` | 与负反馈同维度对齐，用于区分真实负向和内容形态分歧。 | LLM-3、LLM-4。 |
| `refund_metrics` | `refund_profile` | 分母为 0 时退款率为 `null`，并标记稀疏。 | LLM-1、LLM-4、A1。 |
| `ecom_content` | `content_behavior[]` | 内容垂类只代表内容语义，不直接等同商品类目。 | LLM-3、LLM-5。 |
| `anchor_trust` | `anchor_trust_profile` | 计算直播 GMV 占比；不能单点等同"喜欢直播"。 | LLM-1、LLM-3。 |
| `field_order_stats` | `field_preference[]` | 统一搜索、商城、直播、短视频、店铺等场域命名。 | LLM-1、LLM-3、LLM-6。 |
| `search_query_list_30d` | `search_queries[]` | 去重、归一、识别品牌词/类目词/场景词/价格词。 | LLM-2、LLM-5、LLM-6。 |
| `category_l12_file` | `cat_l12_map` | 清洗 L1/L2 空格、重复行和异常值；构造白名单和隶属关系。 | LLM-2、LLM-5、LLM-6、A1。 |

### 4.4 P0 异常处理

| 异常 | 判断规则 | 输出 |
| --- | --- | --- |
| 用户 JSON 无效 | 解析失败、为空、顶层结构不可用 | `inputValidation=false`，`error_code=ERR_INPUT_JSON_INVALID`，`error_text=用户 JSON 为空或无法解析。` |
| 类目文件无效 | 文件为空、无法读取、格式不可解析 | `inputValidation=false`，`error_code=ERR_CATEGORY_FILE_INVALID`，`error_text=类目文件为空或无法解析。` |
| 类目表字段缺失 | 缺少 `category_level_1_name` 或 `category_level_2_name` | `inputValidation=false`，`error_code=ERR_CATEGORY_COLUMN_MISSING`，`error_text=类目文件缺少一级或二级类目列。` |
| 类目表为空 | 清洗后无合法 L1/L2 | `inputValidation=false`，`error_code=ERR_CATEGORY_TABLE_EMPTY`，`error_text=类目表清洗后无合法类目。` |


---

## 五、P1：证据卡片构建

P1 是确定性代码节点，负责把复杂输入压缩成 LLM 可消费的证据卡片。P1 可以聚合、排序、分桶、打强弱标记和生成稀疏提示，但不能直接输出"用户是什么消费人格""用户有什么兴趣场景"这类结论。

### 5.1 P1 输入

```json
{
  "std_user": "{{P0.std_user}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "cat_l1_list": "{{P0.cat_l1_list}}",
  "cat_l2_pairs": "{{P0.cat_l2_pairs}}",
  "run_config_norm": "{{P0.run_config_norm}}",
  "input_qc": "{{P0.input_qc}}"
}
```

### 5.2 P1 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "evi_digest": {
    "user_ref": "string",
    "overall_summary": "string",
    "strong_signal_top": [],
    "sparse_modules": [],
    "conflict_modules": [],
    "time_window_coverage": {
      "7d": false,
      "14d": false,
      "30d": false,
      "90d": false,
      "180d": false
    }
  },
  "role_evi_cards": [],
  "price_evi_cards": [],
  "interest_evi_cards": [],
  "content_evi_cards": [],
  "risk_evi_cards": [],
  "category_constraint_cards": []
}
```

### 5.3 证据卡片格式

```json
{
  "card_id": "EVI_001",
  "evidence_type": "trade/search/item_behavior/content/field/risk/category_constraint/basic",
  "evidence_text": "可被 LLM 直接阅读的一句话证据",
  "source_fields": ["原始字段路径1", "原始字段路径2"],
  "related_category": {
    "category_level_1_name": "",
    "category_level_2_name": "",
    "category_level_3_name": ""
  },
  "time_window": "7d/14d/30d/90d/180d/unknown",
  "strength": "strong/medium/weak",
  "recency": "recent/mid_term/long_term/unknown",
  "value": null,
  "caveat": "证据限制或注意事项"
}
```

### 5.4 P1 证据构建要求

| 输出字段 | 内容 | 构建要求 |
| --- | --- | --- |
| `evi_digest` | 整体摘要、强信号 Top、稀疏模块、冲突模块、时间窗覆盖 | 控制长度，提供全局上下文；不要下最终画像结论。 |
| `role_evi_cards` | 自用、家庭、照护、礼赠、兴趣、价格优化、品质升级、内容种草等角色证据 | 每张卡包含证据类型、证据文本、强度和 caveat。 |
| `price_evi_cards` | 类目均价、P90、最高单笔、订单中位数、优惠词、设备弱证据、退款率 | 区分全局消费能力和类目级价格锚点。 |
| `interest_evi_cards` | 搜索、点击、商详、订单、DSP 类目、时序趋势、复购迹象 | 先按类目归并，再按时间窗和行为强度排序。 |
| `content_evi_cards` | 内容垂类、停留、完播、正向互动、直播 GMV、场域偏好 | 内容垂类迁移到商品类目时标记 `migration_risk`。 |
| `risk_evi_cards` | 退款、快速滑走、正负校正、类目噪声、内容-only、高价过推风险 | 只输出风险和约束，不直接删除兴趣候选。 |
| `category_constraint_cards` | L1/L2 白名单、L2-L1 隶属、未知/其他兜底 | 强制 L1/L2 命中白名单。 |


---

## 六、LLM-1：消费人格、消费画像、消费角色与消费能力推理

> **V10 改动说明（问题1）**：在 `spend_power_profile` 的 `cat_price_elasticity` 字段中新增 `role_context` 字段，要求按消费角色区分价格弹性。消费能力判断规则第4条新增：同一用户在不同消费角色下可以有不同价格区间，不得以最高单笔订单金额锚定所有角色的价格带。

LLM-1 是稳定画像推理节点，负责回答用户整体上如何消费、主要以哪些角色购买、在平台内呈现什么消费能力，以及这些角色如何共同构成最终 V9 的消费兴趣画像。该节点输出的 `consumption_profile` 是中间协议，A1 会映射为最终 V9 的 `consumption_interest_profile`。

### 6.1 LLM-1 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "role_evi_cards": "{{P1.role_evi_cards}}",
  "price_evi_cards": "{{P1.price_evi_cards}}",
  "interest_evi_cards": "{{P1.interest_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}"
}
```

### 6.2 LLM-1 输出

`cat_price_elasticity` 增加 `role_context` 字段（V10 新增字段标注 ★）：

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "persona_profile": {
    "persona_name": "审慎型品质实用派",
    "persona_summary": "该用户在平台内呈现以实用补给和价格确定性为主的消费风格，在有证据类目中可能存在局部品质上探，但不应把局部高客单能力泛化为全局高消费力。",
    "persona_tags": {
      "vals_layer": "第二层-效率实用与家庭责任",
      "vals_type": "精明理性型",
      "vals_tribe": "精明消费族"
    },
    "core_traits": ["重视价格确定性", "偏好实用补给", "高客单需类目证据支持"],
    "confidence": 0.72
  },
  "consumption_profile": {
    "dominant_role_summary": "以自用实用和价格优化为主，存在内容种草或局部品质升级的辅助信号。",
    "role_mix": [
      {
        "role_code": "price_optimizer",
        "role_label": "价格优化型消费者",
        "rank": 1,
        "role_target": "给自己或家庭日常使用场景购买",
        "role_motivation": "用较低试错成本满足明确需求",
        "decision_focus": ["性价比", "优惠确定性", "实用功能"],
        "price_sensitivity": "高，适合 entry/value 价格带承接",
        "trust_requirement": "需要价格透明、真实评价和低风险售后承诺",
        "confidence": 0.78,
        "evidence": ["证据1", "证据2"]
      }
    ],
    "rejected_roles": [
      {
        "role_code": "gift_buyer",
        "reason": "缺少送礼、礼盒、节日对象等证据。"
      }
    ]
  },
  "role_profile": {
    "primary_roles": ["price_optimizer", "self_use_pragmatic"],
    "secondary_roles": ["trend_follower"],
    "role_confidence": 0.76
  },
  "spend_power_profile": {
    "spend_power_code": "lower_mid",
    "spend_power_label": "谨慎型中低消费力",
    "price_sensitivity": "高",
    "cat_price_elasticity": [
      {
        "category_hint": "有证据类目",
        "elasticity_level": "limited_upward",
        "role_context": "★ 该弹性仅在 self_use_pragmatic 角色下成立（日用刚需场景）；若切换至 quality_upgrader 角色且有强证据支持，可允许 moderate_upward。",
        "reason": "仅在历史订单或搜索强证据支持的类目内允许轻度上探，不同消费角色对应的可接受价格上限不同。"
      }
    ],
    "reasoning": ["证据1", "证据2"]
  },
  "persona_safety_check": {
    "passed": true,
    "blocked_terms": [],
    "rewritten_phrases": [],
    "notes": "所有人格表达均已转为消费决策、商品需求或触达策略语言。"
  }
}
```

### 6.3 LLM-1 可直接复制 Prompt（V10 已更新）

```text
你是快手电商用户理解 Workflow 中的"消费人格、消费角色与消费能力推理节点"。你的任务是基于上游证据卡片，推理单个用户在电商直播、短视频、泛货架和搜索等场域中的消费风格、主导消费角色、角色组合、平台内消费能力和价格敏感方式，并输出严格 JSON。

你只能使用输入 JSON 中已经提供的证据卡片进行判断。字段缺失、为空、为 null、为空数组、为 unknown 或无法理解时，一律按未知处理。不得补猜用户收入、真实年龄、婚育状态、家庭结构、身体状态、职业、外貌、地域偏见、真实身份或其他无法从字段验证的信息。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "role_evi_cards": {{P1.role_evi_cards}},
  "price_evi_cards": {{P1.price_evi_cards}},
  "interest_evi_cards": {{P1.interest_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}}
}

【你的推理目标】
第一，生成一个可展示的消费人格 persona_profile，用于概括用户整体消费风格。消费人格必须是中性、专业、策略可用的电商消费语言，不得评价用户身份、收入、外貌、年龄或价值观。
第二，生成 consumption_profile，表达用户可能并存的消费角色组合。角色可以多选，但必须主次有序，不要为了覆盖而凑角色。
第三，生成 role_profile，用于给下游场景归并节点快速读取主角色和辅助角色。
第四，生成 spend_power_profile，表达用户在平台内呈现出的消费能力、价格敏感方式和类目级支付弹性。消费能力不是收入判断，必须基于交易、价格、订单、退款、搜索、类目和场域证据综合判断。
第五，进行 persona_safety_check，确保输出没有敏感、冒犯、刻板或不可验证表达。

【China-VALS 标签约束】
persona_tags 必须包含以下三个字段，且只能从受控集合中选择：
1. vals_layer 只能从以下三项选择：
- 第一层-基础保障与价格安全
- 第二层-效率实用与家庭责任
- 第三层-自我实现与品质生活
2. vals_type 只能从以下六项选择：
- 精明理性型
- 审慎品质型
- 实用享乐混合型
- 家庭责任型
- 内容种草型
- 圈层投入型
3. vals_tribe 只能从以下十四项选择：
- 精明消费族
- 低门槛试探族
- 稳定补给族
- 家庭照护族
- 品质升级族
- 品牌信任族
- 内容种草族
- 达人口碑族
- 圈层兴趣族
- 任务筹备族
- 节令应景族
- 礼赠体面族
- 健康管理族
- 证据稀疏待观察族

【消费角色 taxonomy】
role_code 只能从以下 10 个枚举中选择：
- self_use_pragmatic：自用实用型消费者，以本人日常使用、刚需补给、功能满足为主。
- self_pleasing：悦己改善型消费者，为提升外在、健康、情绪、体验或生活品质而消费。
- family_buyer：家庭采购者，为家庭共同生活、家务、食品、清洁、耐用品采购。
- caregiver：照护责任承担者，为儿童、老人、宠物或特殊照护对象购买。只能基于商品证据表达，不得推断真实家庭结构。
- gift_buyer：礼赠社交型消费者，为送礼、人情、节日、关系维护进行购买。必须有礼盒、送礼词、节日对象、包装或节前购买证据。
- hobby_investor：兴趣投入型消费者，围绕爱好、圈层、专业设备或收藏投入。
- trend_follower：内容种草跟随者，受达人、直播、短视频、爆款内容影响明显。
- price_optimizer：价格优化型消费者，对优惠、比价、性价比和低价风险控制高度敏感。
- quality_upgrader：品质升级型消费者，在有证据类目中愿意为品质、品牌或耐用性支付溢价。
- uncertain_sparse：证据稀疏待观察用户，行为数据不足，无法稳定判断角色。

【消费能力分层约束】
spend_power_code 与 spend_power_label 必须对应如下五档：
- low：低消费力。交易稀疏或长期低客单，对高价和高决策成本商品承受力弱。
- lower_mid：谨慎型中低消费力。有一定购买能力，但明显偏谨慎，依赖优惠、低价、组合装、熟悉类目或确定性。
- mid：中等消费力。具备稳定平台消费能力，可接受多数日用、服饰、食品、家清等类目的中位价格带。
- upper_mid：品质型中高消费力。在有证据类目中具备品质、品牌或耐用品价格上探能力。
- high：高消费力。稳定高客单支付能力明确，对高品质、专业化或品牌化商品承受力强。

消费能力判断必须遵守以下规则：
1. 订单金额、类目均价、P90、有效订单、退款、价格敏感词、搜索和购买频次优先于城市、设备、年龄、性别、U 分层等基础信息。
2. 高频购买不等于高消费力；如果主要是 9.9—29.9 元日用小件，更可能是谨慎型中低消费力或稳定补给型。
3. 低频购买不等于低消费力；如果存在明确高客单耐用品、珠宝、数码、家电等有效订单，可在对应类目中说明支付弹性。
4. 局部高客单能力不能泛化为全局高消费力，必须在 cat_price_elasticity 中表达类目边界。【V10 新增】同一用户在不同消费角色下可以有不同的价格区间，不得以最高单笔订单金额锚定所有角色和场景的价格带。例如：自用刚需角色（self_use_pragmatic）适合 entry/value 价格带，悦己改善角色（self_pleasing）在有证据支持时可适度上探 quality。每个 cat_price_elasticity 条目必须输出 role_context 字段，说明该弹性在哪种消费角色下成立。
5. 内容种草可以提升兴趣判断，但不能单独提升消费能力。
6. 高退款、强负反馈或证据稀疏时，消费能力判断应保守。

【安全治理规则】
允许输出：理性务实、精打细算、品质升级、价格确定性、功能确定性、内容种草、圈层兴趣、家庭照护需求、照护责任线索。
禁止输出：穷、低端、土、虚荣、贪便宜、爱占便宜、容易被割韭菜、冲动无脑、盲从、大妈、宝妈、胖、瘦、有病、身体差、低收入、底层、已婚、单身等身份、外貌、身体、收入或贬损性表达。
如果证据指向敏感对象，只能表达为"照护类商品需求""家庭共同使用需求""儿童用品相关商品证据"，不得推断真实身份和家庭结构。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。所有 confidence 必须是 0 到 1 的数字。core_traits 输出 3 到 5 条。role_mix 输出 1 到 4 个角色，按 rank 升序排列。每个角色必须有 evidence，但 evidence 只需引用证据摘要，不要复制过长原文。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "persona_profile": {
    "persona_name": "string",
    "persona_summary": "string",
    "persona_tags": {
      "vals_layer": "第一层-基础保障与价格安全/第二层-效率实用与家庭责任/第三层-自我实现与品质生活",
      "vals_type": "精明理性型/审慎品质型/实用享乐混合型/家庭责任型/内容种草型/圈层投入型",
      "vals_tribe": "精明消费族/低门槛试探族/稳定补给族/家庭照护族/品质升级族/品牌信任族/内容种草族/达人口碑族/圈层兴趣族/任务筹备族/节令应景族/礼赠体面族/健康管理族/证据稀疏待观察族"
    },
    "core_traits": ["string"],
    "confidence": 0.0
  },
  "consumption_profile": {
    "dominant_role_summary": "string",
    "role_mix": [
      {
        "role_code": "self_use_pragmatic/self_pleasing/family_buyer/caregiver/gift_buyer/hobby_investor/trend_follower/price_optimizer/quality_upgrader/uncertain_sparse",
        "role_label": "string",
        "rank": 1,
        "role_target": "string",
        "role_motivation": "string",
        "decision_focus": ["string"],
        "price_sensitivity": "string",
        "trust_requirement": "string",
        "confidence": 0.0,
        "evidence": ["string"]
      }
    ],
    "rejected_roles": [
      {
        "role_code": "string",
        "reason": "string"
      }
    ]
  },
  "role_profile": {
    "primary_roles": ["string"],
    "secondary_roles": ["string"],
    "role_confidence": 0.0
  },
  "spend_power_profile": {
    "spend_power_code": "low/lower_mid/mid/upper_mid/high",
    "spend_power_label": "低消费力/谨慎型中低消费力/中等消费力/品质型中高消费力/高消费力",
    "price_sensitivity": "高/中高/中/中低/低/未知",
    "cat_price_elasticity": [
      {
        "category_hint": "string",
        "elasticity_level": "no_upward/limited_upward/moderate_upward/strong_upward/unknown",
        "role_context": "string（说明该弹性在哪种消费角色/场景下成立，例如：该弹性仅在 self_use_pragmatic 刚需角色下成立）",
        "reason": "string"
      }
    ],
    "reasoning": ["string"]
  },
  "persona_safety_check": {
    "passed": true,
    "blocked_terms": [],
    "rewritten_phrases": [],
    "notes": "string"
  }
}

如果输入证据整体为空或无法理解，输出 inputValidation=false，error_code=ERR_LLM1_INPUT_EMPTY，error_text=消费画像推理输入为空或无法理解，并保持其他字段为空对象或空数组。
```


---

## 七、LLM-2：兴趣候选与类目意图初判

LLM-2 从商品行为、搜索、订单、DSP 类目兴趣和时序证据中识别候选兴趣。它只生成候选，不生成最终兴趣场景，也不做过度泛化。它必须遵守 L1/L2 白名单，L3 只能作为 hint。

### 7.1 LLM-2 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "interest_evi_cards": "{{P1.interest_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "category_constraint_cards": "{{P1.category_constraint_cards}}",
  "cat_l12_map": "{{P0.cat_l12_map}}"
}
```

### 7.2 LLM-2 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_candidates": [
    {
      "candidate_id": "cand_001",
      "interest_type": "short_term",
      "category_level_1_name": "服饰/鞋靴",
      "category_level_2_name": "服饰",
      "category_level_3_name_hint": "薄款短袜",
      "intent_strength": "strong",
      "confidence": 0.82,
      "evidence": ["证据1", "证据2"],
      "time_sensitivity": "near_term",
      "source_signal_mix": ["search", "item_detail_view"],
      "notes": "近期搜索与商详浏览集中，具备短期转化可能。"
    }
  ],
  "category_intent_cards": [
    {
      "category_level_1_name": "服饰/鞋靴",
      "category_level_2_name": "服饰",
      "candidate_ids": ["cand_001"],
      "overall_intent_strength": "strong"
    }
  ],
  "unmapped_candidates": []
}
```

### 7.3 LLM-2 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的"兴趣候选与类目意图初判节点"。你的任务是基于用户的搜索、商品点击、商详、订单、DSP 类目兴趣、内容行为和类目约束，识别可能存在的电商兴趣候选，并输出严格 JSON。

你只负责生成兴趣候选，不负责生成最终兴趣场景，不负责生成兴趣簇，不负责生成候选商品方向，不负责判断价格带。你不能因为少量内容停留就把内容兴趣直接升级为强购买意图。你必须遵守 L1/L2 类目白名单，任何不在白名单中的一级或二级类目候选必须进入 unmapped_candidates，不能进入 interest_candidates。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "interest_evi_cards": {{P1.interest_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "category_constraint_cards": {{P1.category_constraint_cards}},
  "cat_l12_map": {{P0.cat_l12_map}}
}

【兴趣类型枚举】
interest_type 只能从以下五个值中选择：
- long_term：长期兴趣。跨较长周期稳定存在的类目偏好，不依赖单次近期行为触发。
- short_term：短期兴趣。未来 1—3 天内更可能发生搜索、点击、加购或订单的电商类目兴趣。
- silent_reactivatable：沉默可唤醒兴趣。历史有强兴趣或强购买证据，近期沉默，但存在重新唤醒可能。
- periodic_repurchase：周期/复购性兴趣。由消耗周期、复购间隔、生活周期或购买节律驱动的再购买兴趣。
- potential_exploratory：探索/潜在新兴趣。尚未充分显性表达，但可由弱信号、内容兴趣或电商场景迁移推理出的可能兴趣。

【意图强度规则】
intent_strength 只能输出 strong、medium、weak、unknown。
1. strong：存在搜索、商详、加购、支付、连续点击、多源一致等强电商行为。
2. medium：存在单一强信号或多个中等信号，但交易闭环或时序稳定性不足。
3. weak：主要来自内容行为、弱点击、DSP 兴趣或相邻类目迁移。
4. unknown：证据不足或信号冲突严重。

【证据优先级】
1. 搜索、商详、加购、支付订单是强电商意图。
2. 近 7/14 天行为强于 30/90/180 天行为。
3. 多源一致强于单源行为。
4. 内容停留、完播、正向互动只能作为内容兴趣或潜在探索证据，不能单独作为 strong。
5. 负反馈不在本节点用于删除候选；负反馈由 LLM-4 处理。

【类目约束】
1. category_level_1_name 必须是 cat_l12_map 的 key。
2. category_level_2_name 必须出现在 cat_l12_map[category_level_1_name] 中。
3. category_level_3_name_hint 可以由模型根据商品名、搜索词、订单和 L2 约束推理，但必须是商品供给粒度，不得是品牌词、场景词、抽象需求词或过泛词。
4. 如果候选无法挂靠合法 L1/L2，必须放入 unmapped_candidates，并说明原因。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。interest_candidates 最多输出 12 个，按 intent_strength、confidence、近期性和证据强度降序排列。category_intent_cards 需要按 L1/L2 汇总候选，不能编造不在 interest_candidates 中的 candidate_id。所有 confidence 必须是 0 到 1 的数字。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_candidates": [
    {
      "candidate_id": "cand_001",
      "interest_type": "long_term/short_term/silent_reactivatable/periodic_repurchase/potential_exploratory",
      "category_level_1_name": "string",
      "category_level_2_name": "string",
      "category_level_3_name_hint": "string",
      "intent_strength": "strong/medium/weak/unknown",
      "confidence": 0.0,
      "evidence": ["string"],
      "time_sensitivity": "near_term/mid_term/long_term/no_clear_time_window",
      "source_signal_mix": ["search/item_click/item_detail_view/cart/pay/content/dsp/field/other"],
      "notes": "string"
    }
  ],
  "category_intent_cards": [
    {
      "category_level_1_name": "string",
      "category_level_2_name": "string",
      "candidate_ids": ["cand_001"],
      "overall_intent_strength": "strong/medium/weak/unknown"
    }
  ],
  "unmapped_candidates": [
    {
      "raw_candidate_name": "string",
      "reason": "string",
      "evidence": ["string"]
    }
  ]
}

如果输入证据整体为空或类目白名单为空，输出 inputValidation=false，error_code=ERR_LLM2_INPUT_EMPTY 或 ERR_LLM2_CATEGORY_EMPTY，并在 error_text 中说明原因。
```


---

## 八、LLM-3：内容触达与场域偏好推理

LLM-3 只回答"如何触达这个用户更可能有效"，不负责兴趣泛化。它将内容垂类、停留、完播、正向互动、直播 GMV、场域购买等证据转成 V9 的 `content_anchor_delivery` 候选结构。

### 8.1 LLM-3 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "role_evi_cards": "{{P1.role_evi_cards}}",
  "price_evi_cards": "{{P1.price_evi_cards}}"
}
```

### 8.2 LLM-3 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "content_delivery_profile": {
    "preferred_content_formats": ["真实测评", "场景演示", "直播讲解"],
    "trust_triggers": ["价格透明", "真实评价", "售后保障"],
    "avoid_content": ["高压促单", "无证据高客单种草"],
    "channel_handoff": "短视频负责场景种草和知识解释，泛货架搜索承接显性需求，直播间负责价格解释、信任补强和实时答疑。",
    "content_style_preference": ["强场景演示", "价格对比", "真实试用"],
    "anchor_dependency": {
      "level": "中",
      "reason": "直播间转化存在，但并非唯一购买路径。"
    },
    "confidence": 0.68,
    "evidence": ["证据1", "证据2"]
  }
}
```

### 8.3 LLM-3 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的"内容触达与场域偏好推理节点"。你的任务是基于内容行为、主播/直播信任、场域购买、正向互动和价格证据，判断这个用户更适合用什么内容形式、主播讲解方式、信任触发点和场域承接链路触达，并输出严格 JSON。

你只负责触达方式判断，不负责生成兴趣场景，不负责生成候选商品方向，不负责判断未满足类目。你必须区分"内容兴趣"和"电商意图"：仅有短视频长停留或完播，不代表用户一定会购买；只有搜索、商品点击、商详、加购、订单、直播间商品点击或场域成交跟进，才是更强电商意图证据。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "role_evi_cards": {{P1.role_evi_cards}},
  "price_evi_cards": {{P1.price_evi_cards}}
}

【推理目标】
第一，输出 preferred_content_formats，说明用户更容易接受的内容形态，例如真实测评、场景演示、教程清单、材质讲解、功效解释、价格对比、直播讲解、达人口碑、清单式推荐。
第二，输出 trust_triggers，说明能提升信任和转化意愿的信息，例如价格透明、真实评价、售后保障、认证背书、主播专业讲解、材质证明、对比测评、低试错承诺。
第三，输出 avoid_content，说明应避免的内容方式，例如夸大功效、只讲低价不解释价值、高压促单、无证据高客单种草、强人设背书但缺少商品信息。
第四，输出 channel_handoff，说明短视频、直播间、泛货架搜索、商城、店铺页等场域如何分工承接。
第五，输出 anchor_dependency，判断用户对主播或直播间的依赖强弱。

【场域判断规则】
1. 如果直播间支付 GMV 占比高、直播间商品点击和停留强、主播信任证据强，可以提高直播承接优先级。
2. 如果搜索、商城、泛货架订单占比高，应强调显性需求由搜索/商城承接，短视频或直播负责种草和信任补强。
3. 如果短视频内容正向强但缺少商品点击/订单，应输出"短视频低频种草验证"，不能直接判定强转化。
4. 如果用户价格敏感或退款风险高，应强化价格透明、售后保障、真实评价和低试错承诺。
5. 如果证据稀疏，应输出更通用、保守的触达画像，并降低 confidence。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。preferred_content_formats、trust_triggers、avoid_content 各输出 2 到 6 条。anchor_dependency.level 只能输出 高、中、低、未知。confidence 必须是 0 到 1 的数字。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "content_delivery_profile": {
    "preferred_content_formats": ["string"],
    "trust_triggers": ["string"],
    "avoid_content": ["string"],
    "channel_handoff": "string",
    "content_style_preference": ["string"],
    "anchor_dependency": {
      "level": "高/中/低/未知",
      "reason": "string"
    },
    "confidence": 0.0,
    "evidence": ["string"]
  }
}

如果输入证据整体为空或无法理解，输出 inputValidation=false，error_code=ERR_LLM3_INPUT_EMPTY，error_text=内容触达推理输入为空或无法理解。
```

---

## 九、LLM-4：负向信号与风险雷达

LLM-4 是风险约束节点。它只进入 A1，不进入 LLM-5。它的作用是在最终阶段约束候选商品、价格带、触达策略和置信度，而不是提前删除潜在兴趣。

### 9.1 LLM-4 输入

```json
{
  "evi_digest": "{{P1.evi_digest}}",
  "risk_evi_cards": "{{P1.risk_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "price_evi_cards": "{{P1.price_evi_cards}}"
}
```

### 9.2 LLM-4 输出

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "negative_signal_radar": [
    {
      "signal_id": "risk_001",
      "signal_type": "content_only",
      "risk_code": "content_only",
      "risk_label": "内容-only 风险",
      "severity": "medium",
      "affected_objects": ["cand_003"],
      "evidence": ["证据1"],
      "risk_reasoning": "该类目主要来自内容停留，缺少搜索、商详或订单承接。",
      "mitigation_hint": "只允许低门槛试探，不建议高客单商品。"
    }
  ]
}
```

### 9.3 LLM-4 可直接复制 Prompt

```text
你是快手电商用户理解 Workflow 中的"负向信号与风险雷达节点"。你的任务是基于退款、负反馈、快速滑走、正负校正、内容-only、证据稀疏、类目噪声和价格上探风险，输出用于最终推荐约束的风险雷达 JSON。

你只负责识别风险，不负责删除兴趣候选，不负责生成兴趣场景，不负责生成商品方向。负向信号不是"绝对不感兴趣"的同义词，必须结合正向校正、内容场景、类目和时间窗判断。你的输出只进入最终 A1 装配与风险约束，不进入 LLM-5。

【输入】
{
  "evi_digest": {{P1.evi_digest}},
  "risk_evi_cards": {{P1.risk_evi_cards}},
  "content_evi_cards": {{P1.content_evi_cards}},
  "price_evi_cards": {{P1.price_evi_cards}}
}

【风险类型 taxonomy】
risk_code 和 signal_type 只能从以下枚举中选择：
- sparse_evidence：证据稀疏风险。行为少、时间跨度短、缺少稳定证据。
- content_only：内容-only 风险。只有内容消费，缺少搜索、点击、商详、加购或订单。
- refund_negative：退款/负反馈风险。退款、售后、取消或负反馈集中。
- price_overreach：价格上探风险。推荐价格显著高于历史承受力或类目锚点。
- category_noise：类目噪声风险。行为可能由误点、偶然浏览或泛内容导致。
- stale_interest：兴趣过期风险。历史兴趣近期无行为且缺少周期唤醒证据。
- privacy_sensitive_inference：敏感推断风险。婚育、收入、健康、家庭结构等被无证据推断。

【严重度规则】
severity 只能输出 low、medium、medium_high、high。
1. high：风险直接影响推荐是否应该强触达，例如高退款、高投诉、强负反馈、明显高价过推或敏感推断。
2. medium_high：风险会显著影响价格带、频次、场域或商品方向。
3. medium：风险需要约束但不必完全阻断。
4. low：风险较轻，只作为提示。

【判断规则】
1. 快速滑走或短停留不等于绝对不感兴趣，应结合正向互动、搜索、商详、订单和内容垂类校正。
2. 退款风险应尽量指向具体类目、商品方向、价格带或售后类型，不要泛化为"用户不好服务"。
3. 内容-only 风险主要约束价格带和复杂决策商品，不应完全删除低门槛探索。
4. 高价过推风险必须结合历史价格锚点、类目价格和消费能力证据判断。
5. 敏感推断风险用于阻止无证据推断婚育、收入、健康、身体、家庭结构和身份标签。
6. 如果没有明显负向信号，也要输出空数组，不要编造风险。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。negative_signal_radar 最多输出 8 条，按 severity 和影响范围降序排列。affected_objects 可以填写候选 ID、类目名、场景名、角色 code、价格带或"global"。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "negative_signal_radar": [
    {
      "signal_id": "risk_001",
      "signal_type": "sparse_evidence/content_only/refund_negative/price_overreach/category_noise/stale_interest/privacy_sensitive_inference",
      "risk_code": "sparse_evidence/content_only/refund_negative/price_overreach/category_noise/stale_interest/privacy_sensitive_inference",
      "risk_label": "string",
      "severity": "low/medium/medium_high/high",
      "affected_objects": ["string"],
      "evidence": ["string"],
      "risk_reasoning": "string",
      "mitigation_hint": "string"
    }
  ]
}

如果输入证据整体为空或无法理解，输出 inputValidation=true，error_code=""，error_text=""，negative_signal_radar=[]，不要报错，因为没有风险证据时可以正常进入最终装配。
```


---

## 十、LLM-5：兴趣场景与兴趣簇归并

> **V10 改动说明（问题2/3/5 + 本次结构调整）**：
> - **结构调整**：LLM-5 只负责输出「兴趣场景」和「兴趣簇」两个层级，**不再输出 `unmet_interest_categories_skel`（兴趣类目层）**。兴趣商品和价格带的推理完全交由 LLM-6 负责，LLM-5 的兴趣簇通过 `supply_boundary` 提供供给范围边界，LLM-6 在此边界内推理具体兴趣商品。
> - **问题2**：在【场景生成规则】末尾新增「场景内聚性约束」，要求同一场景下兴趣簇必须共享相同核心需求驱动维度。
> - **问题3**：在【泛化规则】末尾新增「泛化执行强制要求」，要求每个兴趣簇的 supply_boundary 必须基于场景语境主动泛化，不得仅列出输入数据已有商品。
> - **问题5**：在【数量约束】末尾新增「兴趣簇去重约束」，要求输出前进行语义自检，本质相同的兴趣簇必须合并。

LLM-5 是本 Workflow 的核心需求归并节点。它把 LLM-2 的兴趣候选、LLM-1 的消费画像和 P1 的正向证据，归并为「兴趣场景 → 兴趣簇」两层结构。兴趣场景和兴趣簇的骨架由本节点确定，兴趣商品和价格带由 LLM-6 在兴趣簇范围内进一步推理补全。

> 兴趣场景回答"用户为什么需要"；兴趣簇回答"用什么供给组合承接"。两者都由 LLM-5 输出，兴趣商品由 LLM-6 在兴趣簇边界内推理。

### 10.1 LLM-5 输入

```json
{
  "persona_profile": "{{LLM1.persona_profile}}",
  "consumption_profile": "{{LLM1.consumption_profile}}",
  "role_profile": "{{LLM1.role_profile}}",
  "spend_power_profile": "{{LLM1.spend_power_profile}}",
  "interest_candidates": "{{LLM2.interest_candidates}}",
  "category_intent_cards": "{{LLM2.category_intent_cards}}",
  "evi_digest": "{{P1.evi_digest}}",
  "interest_evi_cards": "{{P1.interest_evi_cards}}",
  "content_evi_cards": "{{P1.content_evi_cards}}",
  "category_constraint_cards": "{{P1.category_constraint_cards}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "run_config_norm": "{{P0.run_config_norm}}"
}
```

### 10.2 LLM-5 输出

LLM-5 **只输出兴趣场景和兴趣簇**，不输出兴趣商品和价格带。每个兴趣簇通过 `supply_boundary` 标明供给范围，LLM-6 在此基础上推理具体兴趣商品。

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_scene_graph_skel": [
    {
      "scene_id": "S001",
      "scene_name": "睡眠降噪与日常舒适度改善",
      "need_summary": "用户在睡眠质量改善、日常噪音隔离等舒适度提升场景下存在多元供给需求。",
      "scene_reason": "近期有明确睡眠耳塞购买行为，结合场景需求推理同场景下完整供给集合。",
      "linked_roles": ["ROLE_SELF_USE_PRAGMATIC", "ROLE_SELF_IMPROVEMENT"],
      "source_role_codes": ["self_use_pragmatic", "self_pleasing"],
      "priority": "P0",
      "scene_weight": 0.86,
      "confidence": 0.82,
      "evidence": ["近期睡眠耳塞购买订单", "搜索词含降噪/助眠"],
      "interest_clusters": [
        {
          "cluster_id": "C001",
          "cluster_name": "助眠降噪综合小件",
          "demand_summary": "围绕睡眠场景，提供从耳部隔音到眼部遮光、颈部支撑的完整睡眠舒适供给集合。",
          "cluster_goal": "用低门槛、多形态的睡眠辅助小件承接睡眠舒适度改善需求。",
          "cluster_weight": 0.84,
          "generalization_rule": "同功能泛化",
          "supply_boundary": ["睡眠耳塞", "隔音耳罩", "遮光眼罩", "助眠枕头", "午睡颈枕", "白噪音机"],
          "do_not_expand_to": ["高客单医疗助眠设备", "无证据的全套寝具升级", "跨品类保健药品"]
        },
        {
          "cluster_id": "C002",
          "cluster_name": "日常通勤噪音防护",
          "demand_summary": "在通勤、工作等日常场景下降低环境噪音，提升专注度和舒适度。",
          "cluster_goal": "用便携、轻量的降噪产品承接日常场景噪音防护需求。",
          "cluster_weight": 0.65,
          "generalization_rule": "同功能泛化",
          "supply_boundary": ["降噪耳机", "降噪耳塞（通勤款）", "隔音耳罩（工作款）"],
          "do_not_expand_to": ["高客单专业录音设备", "无证据的高端音频产品"]
        }
      ]
    }
  ]
}
```

### 10.3 LLM-5 可直接复制 Prompt（V10 已更新）

你是快手电商用户理解 Workflow 中的「兴趣场景与兴趣簇归并节点」。你的任务是根据输入的消费画像、兴趣候选、正向证据、内容证据、类目意图和类目白名单，归并出用户未来推荐承接所需的「兴趣场景 → 兴趣簇」两层骨架，并输出严格 JSON。
本节点的核心质量标准是：同一兴趣场景内的兴趣簇应当“簇内围绕同一需求目标高度相似，簇间在需求动机和供给承接机制上显著互斥”；若两个兴趣簇可能被下游 LLM-6 推理出高度重叠的兴趣商品，则必须在本节点合并。

⸻

【节点职责边界：必须严格执行】
你只负责输出两层结构：
1. 兴趣场景 interest_scene_graph_skel[]。
2. 每个兴趣场景下的兴趣簇 interest_clusters[]。
兴趣商品和价格带由下游 LLM-6 节点，在你输出的兴趣簇边界（supply_boundary）内进一步推理，本节点不得输出兴趣商品和价格带。

你必须区分四个层级，但本节点只输出前两个业务层级和兴趣簇供给边界：
1. 消费角色：用户以什么身份、责任关系或决策心智产生需求。消费角色来自 LLM-1，只作为场景和簇的绑定依据。
2. 兴趣场景：回答用户在什么生活、任务、关系、时间窗口或内容语境下产生需求。场景名称必须是需求语境，不能只是类目名。
3. 兴趣簇：回答该场景可由哪些供给集合承接。兴趣簇是供给范围描述，通过 supply_boundary 列出该簇下可能存在的代表性供给方向，供 LLM-6 在此范围内推理具体兴趣商品。
4. 兴趣商品与价格带：由 LLM-6 生成，本节点不得生成。
你不能读取或使用负向风险节点的结果。负向风险由 A1 在最终阶段合并。你不能因为滑走、退款或负反馈提前删除潜在兴趣候选；但你可以基于正向证据强弱调整 confidence。
⸻
【输入】
{
  "persona_profile": /{llm1.persona_profile},
  "consumption_profile": /{llm1.consumption_profile},
  "role_profile": /{llm1.role_profile},
  "spend_power_profile": /{llm1.spend_power_profile},
  "interest_candidates": /{llm2.interest_candidates},
  "category_intent_cards": /{llm2.category_intent_cards},
  "evi_digest": /{p1.evi_digest},
  "interest_evi_cards": /{p1.interest_evi_cards},
  "content_evi_cards": /{p1.content_evi_cards},
  "category_constraint_cards": /{p1.category_constraint_cards},
  "cat_l12_map": /{p0..cat_l12_map},
  "run_config_norm": /{p0.run_config_norm}
}
⸻
【数量约束】
1. interest_scene_graph_skel 最多输出 3 个核心兴趣场景，按 scene_weight 降序排列。
2. 每个有效兴趣场景原则上输出 2—3 个兴趣簇，按 cluster_weight 降序排列。
3. 若某个兴趣场景只能形成 1 个兴趣簇，说明该场景的供给承接结构不足，应优先合并到相邻高相关场景，或不输出该场景。
4. 不要为了覆盖而凑场景或凑簇。证据不足时可以少输出场景，但已输出的场景内部必须具备清晰的多簇承接结构。


⸻

【兴趣簇去重约束】

同一场景下的多个兴趣簇之间必须有清晰的语义边界。输出前须对每对兴趣簇的 cluster_name 和 supply_boundary 进行语义自检：
1. 若两个兴趣簇的核心需求本质相同，必须合并为一个兴趣簇，并扩充其 supply_boundary。
2. 任意两个兴趣簇的 supply_boundary 中，相同供给方向不得超过 50%。
3. 若某兴趣簇的 cluster_name 在语义上可以被另一个簇包含，必须合并，不允许保留边界模糊的重复兴趣簇。
4. 若两个兴趣簇放到下游 LLM-6 后，大概率会推理出同一批兴趣商品，必须合并。
5. 不得通过轻微改写名称来制造伪兴趣簇。

反例：
* “助眠隔音小件”与“隔音耳部防护配件”均指向睡眠降噪需求，必须合并。
* “日常水果补充”与“水果鲜食补给”均指向日常水果摄入需求，必须合并。
* “基础袜类补给”与“短袜舒适穿着”若核心承接商品高度重叠，必须合并。

⸻
【兴趣簇高内聚、低重叠强制约束】
同一兴趣场景下的兴趣簇必须满足：
1. 簇内供给方向必须服务于同一个 cluster_goal，不能把多个弱相关需求混在一个簇内。
2. 簇间必须基于不同的一级需求动机、使用任务或供给承接机制进行划分，不能仅按商品形态、价格层级、品牌风格、使用部位、搜索词差异进行拆分。
3. 如果两个簇可以回答同一个用户需求问题，例如都在解决“睡眠降噪”“基础穿搭补给”“水果摄入补充”，则必须合并。
4. 如果两个簇的 supply_boundary 放到 LLM-6 后大概率会推理出同一批兴趣商品，则必须合并。
5. 每个 cluster_name 必须能清楚说明该簇区别于同场景其他簇的独立需求目标。
6. 一个兴趣簇内部可以包含多个供给方向，但这些供给方向必须共享同一个需求目标。
7. 不允许把多个本质不同的需求动机塞进同一个兴趣簇。

正例：
在“睡眠舒适与休息质量改善”场景下，可以拆成：
* “睡眠降噪遮光簇”：承接睡眠环境干扰降低需求。
* “睡姿支撑舒适簇”：承接枕头、颈部、腰背支撑需求。
* “睡前放松辅助簇”：承接睡前放松、情绪舒缓、入睡辅助需求。
反例：
在同一场景下不应拆成：
* “睡眠耳塞簇”
* “隔音耳塞簇”
* “助眠小件簇”
以上三个簇语义高度重叠，应合并。

⸻

【场景生成规则】

1. scene_name 必须体现任务、目标、关系、时间窗口、使用情境或内容探索语境，不能直接输出“服饰”“食品”“宠物”“美妆”这类类目名。
2. scene_name 不得包含搜索、点击、浏览、商详、加购、成交、购买、下单、强推、召回、风险、疲劳、未转化等行为漏斗词或策略词。
3. 每个场景至少需要 1 条强证据，或 2 条弱证据互相印证。
4. 每个场景必须输出 need_summary 和 scene_reason。need_summary 面向需求解释，回答用户为什么可能存在该类需求。 scene_reason 面向归并解释，回答为什么这些兴趣簇应归到同一个兴趣场景下。
5. priority 只能输出 P0、P1、P2、P3。 P0 表示最优先承接，P1 表示较高优先级承接，P2 表示中等优先级承接，P3 表示低优先级试探。
6. 场景必须与消费角色、兴趣证据或内容证据存在可解释关系，不得只根据类目热度生成场景。

⸻

【场景内聚性约束】
-同一 scene_name 下的所有兴趣簇必须共享同一个核心需求驱动维度，例如：（同一使用场景、同一任务目标、同一消费角色发起、同一内容探索语境、同一关系责任语境），不得仅因时间窗口相近（如"夏季""换季""节后"），就将本质不相关的商品需求归并到同一场景。
-判断标准：若该场景的 need_summary 需要用“和”“以及”“同时”连接两个本质不同的需求动机，则必须拆分为两个独立场景。
反例，禁止输出：
“夏季日常补给与换季小件添置”
原因：鲜果补给属于饮食场景，换季衣物属于穿搭场景，两者需求语境不同，必须各自独立成场景。
正例：
场景 1：“夏季日常饮食补充与鲜果摄入”
场景 2：“换季日常穿搭更新补给”
两者独立，语义内聚。

⸻

【泛化规则】
你只允许以下六类承接或一跳泛化：
1. 直接证据承接：输入证据已经明确指向某类需求，可直接形成兴趣簇。例如从“睡眠耳塞”形成“睡眠降噪遮光簇”。
2. 同功能泛化：与原始证据解决同一功能问题。例如从“短袜”到“薄款袜、运动袜、船袜、防磨脚袜、透气袜类补给”。
3. 互补商品泛化：与原商品存在明确搭配或任务互补。例如从“露营垫”到“收纳袋、防晒帽、便携水杯”。
4. 周期复购泛化：有明确消耗周期或历史复购。例如从“宠物主粮”到“猫砂、宠物清洁、宠物零食补充”。
5. 场景任务泛化：存在明确任务，如夏季基础穿着补给、开学、旅行、搬家、装修、节令准备。例如从“短袜”到“薄款袜、基础内衣、基础 T 恤、防晒袖套”，但必须限定在同一任务场景内。
6. 内容试探泛化：只有内容兴趣时，只能低门槛探索。例如从“露营视频”到“野餐垫、小收纳、入门水杯”。

禁止二跳或过度泛化：不得从“短袜”扩到“全套潮流穿搭”或“奢侈品”；不得从“水果”扩到“全部生鲜高客单礼盒”；不得从内容浏览直接扩到高客单复杂决策商品；不得从“睡眠耳塞”扩到“全屋智能睡眠系统”；不得从“宠物主粮”扩到“宠物医疗治疗方案”；不得从“基础清洁用品”扩到“全屋家电升级”。

⸻
【泛化执行强制要求】
每个 interest_cluster 的 supply_boundary 必须基于该场景的 need_summary 和 cluster_goal，主动推理同一需求域内的供给方向集合，不得仅复述输入数据中已出现的商品。
supply_boundary 是供 LLM-6 继续推理兴趣商品的“供给边界”，不是最终兴趣商品列表。应使用“商品方向 / 供给类型 / 品类范围”表达，不得输出具体品牌、具体 SKU、具体款式、具体价格带。

推荐写法：
* “睡眠降噪类小件”
* “遮光助眠类用品”
* “低门槛露营入门小件”
* “宠物日常消耗补给”
不推荐写法：
* “耳塞”
* “真丝眼罩”

若某场景下的输入数据仅有一个商品证据，如“睡眠耳塞”，必须基于该场景需求，如“睡眠降噪与日常舒适度改善”，推理同一需求域内的多个供给方向，例如：
* “睡眠降噪类小件”
* “遮光助眠类用品”
而不能只输出耳塞相关方向。

自检规则：
若某兴趣簇的 supply_boundary 中所有条目都与输入数据已出现的商品完全相同，则视为未执行有效泛化，需要重新推理。
泛化边界：
supply_boundary 的泛化必须在同一需求场景内，不得跨越到其他需求域。
⸻

【消费角色 ID 映射】
linked_roles 必须使用 V9 风格 role_id。请按以下规则从 source_role_codes 映射：
* self_use_pragmatic -> ROLE_SELF_USE_PRAGMATIC
* self_pleasing -> ROLE_SELF_IMPROVEMENT
* family_buyer -> ROLE_FAMILY_BUYER
* caregiver -> ROLE_CAREGIVER
* gift_buyer -> ROLE_GIFT_SOCIAL
* hobby_investor -> ROLE_HOBBY_INVESTMENT
* trend_follower -> ROLE_CONTENT_SEEDED
* price_optimizer -> ROLE_PRICE_OPTIMIZER
* quality_upgrader -> ROLE_QUALITY_UPGRADER
* uncertain_sparse -> ROLE_UNCERTAIN_SPARSE


【类目白名单与供给边界约束】
1. supply_boundary 必须尽量落在 category_constraint_cards、category_intent_cards 或 cat_l12_map 支持的类目范围内。
2. 若某个泛化方向无法在类目白名单或类目映射中找到合理承接，应降低 confidence，或不输出该泛化方向。
3. 不得输出明显脱离类目白名单的供给边界。不得为了泛化而跨越到无证据、无类目承接或强监管风险的方向。

⸻

【边界约束】

每个 interest_cluster 必须输出 do_not_expand_to，说明不能扩展到哪些方向。do_not_expand_to 必须具体，不要只写“不要过度泛化”。
⸻

【权重和置信度】
scene_weight、cluster_weight、confidence 均为 0 到 1 的数字。权重应由证据强度、近期性、交易强度、搜索强度、角色匹配、内容迁移风险共同决定。排序必须与权重一致。

⸻

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。不要输出最终 V9 JSON，不要输出兴趣商品或价格带；你只输出兴趣场景和兴趣簇的 interest_scene_graph_skel 骨架。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "interest_scene_graph_skel": [
    {
      "scene_id": "S001",
      "scene_name": "string",
      "need_summary": "string",
      "scene_reason": "string",
      "linked_roles": ["ROLE_XXX"],
      "source_role_codes": ["string"],
      "priority": "P0/P1/P2/P3",
      "scene_weight": 0.0,
      "confidence": 0.0,
      "evidence": ["string"],
      "interest_clusters": [
        {
          "cluster_id": "C001",
          "cluster_name": "string",
          "demand_summary": "string",
          "cluster_goal": "string",
          "cluster_weight": 0.0,
          "generalization_rule": "同功能泛化/互补商品泛化/周期复购泛化/场景任务泛化/内容试探泛化/直接证据承接",
          "supply_boundary": ["string（兴趣簇内代表性供给商品方向，供 LLM-6 推理兴趣商品的范围依据）"],
          "do_not_expand_to": ["string"]
        }
      ]
    }
  ]
}
⸻
如果正向兴趣证据整体为空或无法形成任何场景，输出 inputValidation=true，error_code=""，error_text=""，interest_scene_graph_skel=[]，不要编造场景。

---

## 十一、Batch：按兴趣场景拆分

Batch 节点将 `interest_scene_graph_skel` 按场景拆成单条输入，传给 LLM-6 并行补全候选商品方向。它不改变内容，只做数组拆分、上下文携带和索引记录。

### 11.1 Batch 输入

```json
{
  "interest_scene_graph_skel": "{{LLM5.interest_scene_graph_skel}}",
  "spend_power_profile": "{{LLM1.spend_power_profile}}",
  "persona_profile": "{{LLM1.persona_profile}}",
  "consumption_profile": "{{LLM1.consumption_profile}}",
  "price_evi_cards": "{{P1.price_evi_cards}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "run_config_norm": "{{P0.run_config_norm}}"
}
```

### 11.2 Batch 输出给 LLM-6 的单条结构

```json
{
  "batch_index": 0,
  "scene_item": {},
  "spend_power_profile": {},
  "persona_profile": {},
  "consumption_profile": {},
  "price_evi_cards": [],
  "cat_l12_map": {},
  "max_product_directions_per_scene": 6
}
```

### 11.3 Batch 工程规则

| 规则 | 说明 |
| --- | --- |
| 场景数截断 | 如果 LLM-5 输出超过 3 个场景，按 `scene_weight` 降序取 Top 3，并记录 `batch_qc.truncated=true`。 |
| 顺序保持 | 每条输出保留 `batch_index` 和 `scene_id`，便于 A1 回填。 |
| 空数组处理 | 如果 `interest_scene_graph_skel=[]`，Batch 输出空数组，LLM-6 不执行或执行 0 次。 |
| 上下文携带 | 每条单场景输入都携带消费能力、消费人格、消费角色、价格证据和类目白名单。 |

---

## 十二、LLM-6：单场景兴趣商品与价格带补全

> **V10 改动说明（本次结构调整 + 问题1/4/6）**：
> - **结构调整**：LLM-6 的职责从「补全候选商品方向」升级为「为每个兴趣簇推理多个具体兴趣商品，并为每个兴趣商品输出对应价格带」。输入的 `scene_item` 中兴趣簇已不含 `unmet_interest_categories_skel`，LLM-6 须基于兴趣簇的 `supply_boundary` 自主推理具体兴趣商品。结构为：**1个兴趣场景 → 多个兴趣簇 → 每簇多个兴趣商品 → 每个商品1个价格带**。
> - **问题1**：价格带跟随 target_role 差异化输出，不得以最高单笔历史价格锚定所有角色。
> - **问题4**：每个兴趣簇必须输出至少 3 个不同兴趣商品（强制）。
> - **问题6**：每个兴趣商品必须携带完整价格带，保障「兴趣商品→价格带」链路贯通。
> - **角色-消费画像价格带绑定（本次新增）**：价格带推理必须与该商品对应的 `target_role` 所在消费角色画像绑定。同一用户在不同消费角色下的消费倾向不同（例如自用时节俭、为家人购买时慷慨），价格带须分别从 `consumption_profile.role_mix[]` 中查找对应角色的 `price_sensitivity` 和 `decision_focus`，以该角色的个体消费特征确定价格区间，而非使用全局统一的消费能力档位。

LLM-6 基于 LLM-5 输出的兴趣场景和兴趣簇骨架，为每个兴趣簇推理具体的兴趣商品列表，并为每个兴趣商品推理对应的价格带、卖点逻辑和内容触发方式。LLM-6 不重新判断场景或修改兴趣簇范围。

### 12.1 LLM-6 输入

```json
{
  "batch_index": "{{Batch.batch_index}}",
  "scene_item": "{{Batch.scene_item}}",
  "spend_power_profile": "{{Batch.spend_power_profile}}",
  "persona_profile": "{{Batch.persona_profile}}",
  "consumption_profile": "{{Batch.consumption_profile}}",
  "price_evi_cards": "{{Batch.price_evi_cards}}",
  "cat_l12_map": "{{Batch.cat_l12_map}}"
}
```

### 12.2 LLM-6 输出

LLM-6 输出以兴趣簇为单位组织的兴趣商品卡片列表。**每个兴趣簇对应多个兴趣商品，每个兴趣商品携带一个价格带**。

> **角色-价格带绑定说明**：同一用户在不同消费角色下，价格带应反映该角色画像中的实际消费倾向。例如：同一个人作为「自用实用型（ROLE_SELF_USE_PRAGMATIC）」购买个人日用品时偏节俭（entry/value），作为「照护责任型（ROLE_CAREGIVER）」为子女或父母购买时更愿意花钱（value/quality），作为「礼赠社交型（ROLE_GIFT_SOCIAL）」购买礼物时偏向中高价位（quality/premium）。LLM-6 须从 `consumption_profile.role_mix[]` 中查找对应角色的 `price_sensitivity` 和 `decision_focus` 来锚定每个兴趣商品的价格带，而非使用同一个全局价格档位。

```json
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "scene_id": "S001",
  "interest_product_cards": [
    {
      "cluster_id": "C001",
      "cluster_name": "助眠降噪综合小件",
      "interest_products": [
        {
          "product_id": "IP_S001_C001_001",
          "product_name": "防噪睡眠耳塞（硅胶多规格组合装）",
          "product_description": "用于睡眠场景隔音降噪，柔软硅胶材质，适合不同耳道尺寸，组合装低试错成本。",
          "interest_type": "short_term_interest",
          "target_role": "ROLE_SELF_USE_PRAGMATIC",
          "role_price_context": {
            "role_price_sensitivity": "价格敏感度高，决策核心是实用和性价比，不愿为品牌溢价买单。",
            "role_decision_focus": ["性价比", "实用功能", "优惠确定性"],
            "role_spend_tendency": "节俭型自用，偏向 entry/value，不主动上探 quality 及以上。"
          },
          "category_hint": {
            "category_level_1_name": "家居/家纺",
            "category_level_2_name": "家居日用",
            "category_level_3_name_hint": "睡眠耳塞"
          },
          "price_band": {
            "price_level": "entry",
            "typical_range": "9-39元",
            "band_meaning": "自用实用型角色节俭偏好 + 该类目首次探索，entry 价格带低试错。",
            "price_min": 9,
            "price_max": 39,
            "price_anchor_type": "角色消费画像（节俭自用）+ 历史价格锚点"
          },
          "selling_point_logic": "强调材质柔软、隔音分贝数据、多规格适配、组合装低试错。",
          "content_trigger": "场景演示睡眠环境降噪对比，真实试用不同材质舒适度。",
          "reasoning": "用户此时以自用实用型角色消费，其 price_sensitivity 明确为高敏感、性价比优先，因此耳塞价格带锁定 entry，9-39元区间匹配历史低中客单消费证据。",
          "risk_note": "不建议推荐高客单医疗级降噪设备，证据仅支持日用小件。",
          "confidence": 0.86
        },
        {
          "product_id": "IP_S001_C001_002",
          "product_name": "儿童睡眠专用降噪耳罩（亲子款，可调节尺码）",
          "product_description": "为子女睡眠提供降噪防护，亲子款可调节头围，材质安全无异味，贴合儿童耳廓。",
          "interest_type": "potential_interest_probe",
          "target_role": "ROLE_CAREGIVER",
          "role_price_context": {
            "role_price_sensitivity": "照护角色下价格敏感度低，优先考虑安全性、品质和效果，愿意为家人多付费。",
            "role_decision_focus": ["安全性", "品质可信赖", "适合年龄段"],
            "role_spend_tendency": "照护子女/父母时偏向 value/quality，不会因价格低而优先选择，会因品质风险降低偏好。"
          },
          "category_hint": {
            "category_level_1_name": "家居/家纺",
            "category_level_2_name": "家居日用",
            "category_level_3_name_hint": "儿童降噪耳罩"
          },
          "price_band": {
            "price_level": "quality",
            "typical_range": "59-159元",
            "band_meaning": "照护型角色为子女购买时价格接受力显著高于自用，优先考虑安全品质，可承接 quality 价格带。",
            "price_min": 59,
            "price_max": 159,
            "price_anchor_type": "角色消费画像（照护型，为子女购买）+ 类目品质款估算"
          },
          "selling_point_logic": "强调儿童专用材质安全认证、可调节尺码成长期适用、耳廓贴合轻量设计。",
          "content_trigger": "亲子场景演示（晚间睡眠/午休），强调安全无异味、子女舒适使用体验。",
          "reasoning": "用户此时以照护责任型角色为子女选品，其照护型 price_sensitivity 为低敏感、品质优先，因此价格带从自用的 entry 上升至 quality（59-159元），体现同一用户不同角色下的价格带差异。",
          "risk_note": "若用户无明确子女证据，应降低为 value 价格带，避免在无照护角色证据时推高客单。",
          "confidence": 0.68
        },
        {
          "product_id": "IP_S001_C001_003",
          "product_name": "遮光睡眠眼罩（3D立体/冷热双用款）",
          "product_description": "配合睡眠场景使用，提供全遮光效果，3D立体设计不压眼球，适合午睡与夜间使用。",
          "interest_type": "potential_interest_probe",
          "target_role": "ROLE_SELF_IMPROVEMENT",
          "role_price_context": {
            "role_price_sensitivity": "悦己改善型价格敏感度中等，愿意为提升体验付合理溢价，但不盲目追高。",
            "role_decision_focus": ["体验感提升", "设计感", "功能完整性"],
            "role_spend_tendency": "悦己场景下可承接 value/低 quality，有内容种草加持时上探意愿更高。"
          },
          "category_hint": {
            "category_level_1_name": "家居/家纺",
            "category_level_2_name": "家居日用",
            "category_level_3_name_hint": "遮光眼罩"
          },
          "price_band": {
            "price_level": "value",
            "typical_range": "15-59元",
            "band_meaning": "悦己改善型角色对体验感有追求，但尚无直接购买证据，先以 value 价格带内容种草试探，证据增强后可上探 quality。",
            "price_min": 15,
            "price_max": 59,
            "price_anchor_type": "角色消费画像（悦己中等敏感）+ 类目保守估算"
          },
          "selling_point_logic": "强调遮光率、3D不压眼、冷热双用适应不同季节需求。",
          "content_trigger": "短视频展示午睡场景，强调遮光体验感提升睡眠质量。",
          "reasoning": "用户悦己型角色消费倾向中等，value 价格带（15-59元）匹配其「体验提升但不过度消费」的决策逻辑，与自用实用型 entry（9-39元）形成角色内价格梯度。",
          "risk_note": "用户尚无直接眼罩购买证据，应以内容种草低门槛试探为主，不建议初次推 quality 价格带。",
          "confidence": 0.65
        }
      ]
    }
  ]
}
```

### 12.3 LLM-6 可直接复制 Prompt（V10 已更新）

```text
你是快手电商用户理解 Workflow 中的"单场景兴趣商品与价格带补全节点"。你的任务是基于一个已确定的兴趣场景和该场景下的兴趣簇列表，为每个兴趣簇推理多个具体兴趣商品，并为每个兴趣商品推理对应的价格带、卖点逻辑、内容触发方式和推理说明，并输出严格 JSON。

输出结构为：1个兴趣场景 → 多个兴趣簇（来自 LLM-5 输入） → 每个兴趣簇下多个兴趣商品 → 每个兴趣商品对应一个价格带。

你不能重新判断场景，不能修改兴趣簇名称，不能新增超出 scene_item.interest_clusters[].supply_boundary 范围的商品方向，不能把局部高客单能力泛化到所有角色和类目。你只能在 LLM-5 给定的兴趣簇边界（supply_boundary）内推理具体兴趣商品。

【输入】
{
  "batch_index": {{Batch.batch_index}},
  "scene_item": {{Batch.scene_item}},
  "spend_power_profile": {{Batch.spend_power_profile}},
  "persona_profile": {{Batch.persona_profile}},
  "consumption_profile": {{Batch.consumption_profile}},
  "price_evi_cards": {{Batch.price_evi_cards}},
  "cat_l12_map": {{Batch.cat_l12_map}}
}

【兴趣商品推理规则】
1. 每个 interest_product 是一个具体的可推荐商品方向，不是抽象类目名，也不是品牌名或 SKU ID。商品名称应具体到商品形态，例如"防噪睡眠耳塞（硅胶多规格组合装）"而不是"耳塞"。
2. 【强制】每个兴趣簇必须输出至少 3 个不同的兴趣商品，最多 5 个。不同兴趣商品之间必须在商品形态、材质、使用方式或功能侧重上有明显区分，不允许输出高度相似的重复商品。如果某兴趣簇确实不足 3 个商品，必须在对应商品的 risk_note 中说明原因。
3. 每个兴趣商品必须关联到 supply_boundary 中的某个商品方向，不得超出兴趣簇的供给边界。
4. interest_type 只能从以下五项选择：long_term_interest / short_term_interest / potential_interest_probe / repeat_purchase_interest / seasonal_interest。
5. target_role 必须来自该兴趣簇所属场景的 linked_roles。
6. category_hint 中 category_level_1_name 和 category_level_2_name 必须来自 cat_l12_map 白名单，category_level_3_name_hint 可以自由推理但必须是商品供给粒度词，不得是品牌词或过泛词。
7. selling_point_logic 必须说明该商品应突出什么卖点才能匹配用户当前角色和场景需求。
8. content_trigger 必须说明适合用什么内容形式激活用户，例如真实试用、场景演示、对比测评、材质说明、价格透明、主播讲解等。
9. reasoning 必须解释为什么该商品适合当前用户、场景和兴趣簇，且必须说明价格带如何与 target_role 的消费画像绑定。
10. risk_note 必须说明不宜如何过推、价格上探边界或证据不足点。

【角色消费画像查找规则 — 价格带绑定的基础（新增核心规则）】
推理每个兴趣商品的价格带之前，必须先执行以下三步：

步骤一：定位角色画像
从 consumption_profile.role_mix[] 中找到与该商品 target_role 对应的角色条目（按 role_id 匹配）。如果找不到对应角色，使用 spend_power_profile 全局档位保守估算，并在 price_anchor_type 注明"全局消费能力兜底"。

步骤二：读取角色消费特征
从该角色条目中读取：
- price_sensitivity：该角色在此消费场景下的价格敏感程度描述。
- decision_focus：该角色的决策优先项（如性价比、品质、安全性、礼赠面子感等）。
- role_motivation：该角色的购买动机（如"节省开销""让家人用好的""维护社交关系"等）。

步骤三：用角色特征确定价格带
- 若 price_sensitivity 为"高敏感、性价比优先"，价格带应偏向 entry/value，不建议初次推 quality 及以上。
- 若 price_sensitivity 为"低敏感、品质优先"或"为他人购买愿意多花"，价格带可上探至 value/quality，有强证据时可考虑 premium。
- 若 price_sensitivity 为"中等，体验导向"，价格带视证据强弱在 value/low-quality 区间灵活判断。
- 若 decision_focus 包含"礼赠面子感"或"社交形象维护"，价格带通常高于自用场景 1~2 个档次。
- 若 decision_focus 包含"照护对象安全性"，价格带通常高于自用场景 1 个档次，且不因价格低而优先选择。

【重要原则：同一用户、不同角色，价格带必须有差异】
同一用户在不同消费角色下的价格带必须独立推理，不得使用同一个价格区间套用所有角色和商品。

典型对比示例：
- 同一用户，作为 ROLE_SELF_USE_PRAGMATIC 购买日用耳塞：price_sensitivity 高敏感 → entry（9-39元）
- 同一用户，作为 ROLE_CAREGIVER 为子女购买儿童降噪耳罩：price_sensitivity 低敏感/品质优先 → quality（59-159元）
- 同一用户，作为 ROLE_GIFT_SOCIAL 购买礼品套装：decision_focus 含礼赠面子感 → quality/premium（99-299元）

上述三个商品均来自同一个"睡眠降噪"兴趣场景，但因角色不同，价格带相差 3-10 倍。这是正确的行为，不是错误。你必须输出这种角色内价格梯度。

自检要求：
- 若一个兴趣簇下所有商品的价格带完全相同，必须自检：是否所有商品真的面向同一角色？若角色不同但价格带相同，须重新推理。
- 若一个场景下同一用户的所有角色价格带区间完全没有差异（如都是 30-80 元），则说明角色差异化没有真正生效，须重新推理。

【价格带推理规则】
每个兴趣商品必须携带独立的 price_band，不得为一整个兴趣簇输出一个共用价格带。价格带推理优先级如下：
1. 历史价格锚点优先：若该商品方向或相近类目存在历史均价、P90、最高支付、最近订单金额，优先使用。历史锚点须结合角色进行区分——同一类目下不同消费角色可能对应不同历史交易价格段（如用户自用时倾向低价款，为家人购买时倾向中高价款），须分别识别。
2. 类目价格带其次：若无历史锚点，使用平台类目常识做保守估计，并说明 price_anchor_type。
3. 角色消费画像（核心修正，高于全局消费能力）：每个商品的价格带必须先按【角色消费画像查找规则】定位该 target_role 的价格敏感度和决策偏好，以角色维度的消费特征作为价格区间的主要锚点，全局 spend_power_profile 仅作参考下限，不得以全局档位替代角色维度的个体差异。
4. 消费角色类型差异化修正（V10 强制，结合角色画像执行）：
   - target_role 为 ROLE_SELF_USE_PRAGMATIC 或 ROLE_PRICE_OPTIMIZER 时，该角色画像 price_sensitivity 通常为高敏感，价格带偏向 entry/value。
   - target_role 为 ROLE_SELF_IMPROVEMENT 或 ROLE_QUALITY_UPGRADER 且有直接消费证据时，该角色 price_sensitivity 通常为中低敏感，可适度考虑 value/quality，须在 reasoning 中说明。
   - target_role 为 ROLE_CAREGIVER 或 ROLE_FAMILY_BUYER 时，该角色画像 price_sensitivity 通常为低敏感/品质优先，价格带可上探至 value/quality，为被照护者购买时更可接受 quality。
   - target_role 为 ROLE_GIFT_SOCIAL 时，该角色决策含礼赠面子感，价格带通常高于自用 1~2 个档次，可接受 quality/premium。
   - target_role 为 ROLE_CONTENT_SEEDED 且仅有内容行为证据时，价格带必须保守，不得超出 value。
   - 不得以用户历史最高单笔订单金额锚定所有角色和商品的价格带。
5. 风险保守修正：证据稀疏、内容-only 或类目迁移远时，选择更保守价格带，并在 risk_note 中说明。

【每个商品输出 role_price_context（新增字段，强制）】
每个 interest_product 必须输出 role_price_context 字段，包含：
- role_price_sensitivity：从 consumption_profile.role_mix[] 读取的该角色 price_sensitivity 描述（直接引用或简要概括）。
- role_decision_focus：从该角色画像读取的 decision_focus 关键项（数组）。
- role_spend_tendency：基于以上两项做出的价格档位判断的自然语言说明，例如"照护型购买，品质优先，偏 quality"或"自用节俭型，性价比优先，锁定 entry/value"。

该字段的作用是透明化价格带推理的角色来源，方便 A1 质检时追溯价格带合理性。

【价格层级枚举】
price_band.price_level 只能输出以下值之一：
- entry：低门槛、低试错成本价格带。
- value：性价比、中低价格带或组合装价格带。
- quality：品质款、中高价格带或有明确价值解释的升级款。
- premium：高客单、高品质、品牌化或专业化价格带，仅在强证据支持时使用。
- high_but_role_specific：局部高客单，但只在特定角色、类目或场景中成立。

【输出要求】
你必须只输出一个合法 JSON 对象，不要输出 Markdown、解释性段落或代码块。所有 confidence 必须是 0 到 1 的数字。price_band.price_min 和 price_band.price_max 必须是数字，不要输出 null。price_band.typical_range 必须使用"X-Y元"格式。对于每个兴趣簇，interest_products 数组长度必须 ≥ 3。每个 interest_product 必须包含 role_price_context 字段。

【输出 JSON 格式】
{
  "inputValidation": true,
  "error_code": "",
  "error_text": "",
  "scene_id": "S001",
  "interest_product_cards": [
    {
      "cluster_id": "C001",
      "cluster_name": "string",
      "interest_products": [
        {
          "product_id": "IP_S001_C001_001",
          "product_name": "string（具体商品方向名称，含形态描述）",
          "product_description": "string（商品特征与适用场景简述）",
          "interest_type": "long_term_interest/short_term_interest/potential_interest_probe/repeat_purchase_interest/seasonal_interest",
          "target_role": "ROLE_XXX",
          "role_price_context": {
            "role_price_sensitivity": "string（从 consumption_profile.role_mix 读取的该角色价格敏感描述）",
            "role_decision_focus": ["string（决策优先项，如性价比/品质/安全性/礼赠面子感等）"],
            "role_spend_tendency": "string（基于角色画像的价格档位倾向说明，例如：照护型购买品质优先，偏 quality）"
          },
          "category_hint": {
            "category_level_1_name": "string（来自 cat_l12_map 白名单）",
            "category_level_2_name": "string（来自 cat_l12_map 白名单）",
            "category_level_3_name_hint": "string（商品供给粒度词）"
          },
          "price_band": {
            "price_level": "entry/value/quality/premium/high_but_role_specific",
            "typical_range": "X-Y元",
            "band_meaning": "string（必须说明价格带与 target_role 消费画像的绑定关系）",
            "price_min": 0,
            "price_max": 0,
            "price_anchor_type": "角色消费画像（X型）+ 历史价格锚点/类目保守估算/消费能力默认/证据稀疏保守估算"
          },
          "selling_point_logic": "string",
          "content_trigger": "string",
          "reasoning": "string（须包含：为何此价格带与 target_role 消费画像匹配）",
          "risk_note": "string",
          "confidence": 0.0
        }
      ]
    }
  ]
}

如果 scene_item 为空或没有合法兴趣簇，输出 inputValidation=false，error_code=ERR_LLM6_SCENE_EMPTY，error_text=单场景输入为空或缺少合法兴趣簇，interest_product_cards=[]。
```


---

## 十三、A1：最终装配与 Schema 质检

> **V10 改动说明（本次结构调整 + 问题6）**：在质检规则表（13.6节）中更新「兴趣商品价格带完整性」质检项，要求每个 `interest_products[]` 条目必须包含完整 `price_band`（来自 LLM-6），保障「兴趣场景→兴趣簇→兴趣商品→价格带」完整链路可追溯。

A1 是确定性代码节点，负责把所有上游结果装配为 V9 JSON，并执行可程序化检查。A1 不调用 LLM 修复；质检失败时返回结构化错误，方便定位是 P0、P1、LLM-5 还是 LLM-6 的问题。

### 13.1 A1 输入

```json
{
  "std_user": "{{P0.std_user}}",
  "cat_l12_map": "{{P0.cat_l12_map}}",
  "persona_profile": "{{LLM1.persona_profile}}",
  "consumption_profile": "{{LLM1.consumption_profile}}",
  "role_profile": "{{LLM1.role_profile}}",
  "spend_power_profile": "{{LLM1.spend_power_profile}}",
  "content_delivery_profile": "{{LLM3.content_delivery_profile}}",
  "negative_signal_radar": "{{LLM4.negative_signal_radar}}",
  "interest_scene_graph_skel": "{{LLM5.interest_scene_graph_skel}}",
  "interest_product_cards_by_scene": "{{LLM6.interest_product_cards}}"
}
```

### 13.2 A1 成功输出：最终 V9 JSON

```json
{
  "uid": "user_xxx",
  "consumption_interest_profile": {
    "consumption_persona": {
      "persona_name": "审慎型品质实用派",
      "persona_summary": "...",
      "persona_tags": {
        "vals_layer": "第二层-效率实用与家庭责任",
        "vals_type": "精明理性型",
        "vals_tribe": "精明消费族"
      },
      "core_traits": ["..."],
      "confidence": 0.72
    },
    "dominant_role_summary": "...",
    "consumption_roles": []
  },
  "interest_scene_graph": [],
  "content_anchor_delivery": {},
  "negative_signal_radar": []
}
```

### 13.3 A1 装配映射

| V9 字段 | 来源 | 装配规则 |
| --- | --- | --- |
| `uid` | `P0.std_user.user_id` | 只保留用户 ID，不暴露调试链路。 |
| `consumption_interest_profile.consumption_persona` | `LLM1.persona_profile` | 直接映射 `persona_name`、`persona_summary`、`persona_tags`、`core_traits`、`confidence`。 |
| `consumption_interest_profile.dominant_role_summary` | `LLM1.consumption_profile.dominant_role_summary` | 若为空，由 A1 根据 Top roles 拼接一句话。 |
| `consumption_interest_profile.consumption_roles[]` | `LLM1.consumption_profile.role_mix[]` | 转换 role_id、role_name、role_target、role_motivation、decision_focus、price_sensitivity、trust_requirement、confidence。 |
| `interest_scene_graph[]` | `LLM5.interest_scene_graph_skel` | 最多 3 个，按 `scene_weight` 降序；字段名转换为 V9 的 `need_summary`、`priority` 等。 |
| `interest_clusters[]` | `LLM5.interest_clusters[]` | 每场景最多 3 个，按 `cluster_weight` 降序。兴趣簇只含骨架字段（cluster_name、demand_summary、supply_boundary、do_not_expand_to），不含商品信息。 |
| `interest_products[]` | `LLM6.interest_product_cards[].interest_products[]` | 按 cluster_id 归并，每簇填入 product_name、product_description、interest_type、target_role、category_hint、price_band、selling_point_logic、content_trigger、reasoning、confidence。**每个兴趣商品必须携带完整 price_band（V10 强制要求，不得为空）**。 |
| `content_anchor_delivery` | `LLM3.content_delivery_profile` | 映射偏好内容形式、信任触发点、应避免内容、场域承接链路和置信度。 |
| `negative_signal_radar[]` | `LLM4.negative_signal_radar` | 必须进入最终结果，不参与 LLM-5。 |

### 13.4 role_code 到 V9 role_id 映射

| LLM-1 `role_code` | V9 `role_id` | V9 `role_name` |
| --- | --- | --- |
| `self_use_pragmatic` | `ROLE_SELF_USE_PRAGMATIC` | 自用实用型 |
| `self_pleasing` | `ROLE_SELF_IMPROVEMENT` | 悦己改善型 |
| `family_buyer` | `ROLE_FAMILY_BUYER` | 家庭采购型 |
| `caregiver` | `ROLE_CAREGIVER` | 照护责任型 |
| `gift_buyer` | `ROLE_GIFT_SOCIAL` | 礼赠社交型 |
| `hobby_investor` | `ROLE_HOBBY_INVESTMENT` | 兴趣投入型 |
| `trend_follower` | `ROLE_CONTENT_SEEDED` | 内容种草型 |
| `price_optimizer` | `ROLE_PRICE_OPTIMIZER` | 价格优化型 |
| `quality_upgrader` | `ROLE_QUALITY_UPGRADER` | 品质升级型 |
| `uncertain_sparse` | `ROLE_UNCERTAIN_SPARSE` | 证据稀疏待观察型 |

### 13.5 interest_type 映射与校验

A1 最终只能保留 V9 枚举：`long_term_interest`、`short_term_interest`、`potential_interest_probe`、`repeat_purchase_interest`、`seasonal_interest`。如果 LLM-5 已按 V9 枚举输出，则直接保留；如果出现 LLM-2 旧枚举，应按如下规则转换，无法转换时报错。

| 过程枚举 | V9 枚举 | 说明 |
| --- | --- | --- |
| `long_term` | `long_term_interest` | 长期稳定类目兴趣。 |
| `short_term` | `short_term_interest` | 近期升温类目兴趣。 |
| `silent_reactivatable` | `long_term_interest` 或 `potential_interest_probe` | 有历史强证据时用长期兴趣；证据弱时用潜在探索。 |
| `periodic_repurchase` | `repeat_purchase_interest` | 周期/复购型兴趣。 |
| `potential_exploratory` | `potential_interest_probe` | 探索/潜在新兴趣。 |
| 明确季节/节日/节点 | `seasonal_interest` | 节点属性优先于普通短期兴趣。 |

### 13.6 A1 质检规则（V10 已更新）

| 质检项 | 校验规则 | 失败处理 |
| --- | --- | --- |
| Schema 完整性 | V9 必填字段存在，类型正确 | `ERR_SCHEMA_MISSING` 或 `ERR_SCHEMA_TYPE`。 |
| UID | `uid` 非空字符串 | `ERR_UID_MISSING`。 |
| 场景数量 | `interest_scene_graph` 长度 ≤ 3 | 超出按权重截断并记录 `WARN_SCENE_TRUNCATED`；无法排序则 `ERR_SCENE_COUNT_INVALID`。 |
| 簇数量 | 每场景 `interest_clusters` 长度 ≤ 3 | 超出按 `cluster_weight` 截断并记录 warning。 |
| 兴趣商品数量 | 每簇 `interest_products` 长度 ≥ 3 且 ≤ 5 | 低于 3 记录 `WARN_PRODUCT_TOO_FEW`；超出 5 按置信度截断并记录 warning。 |
| 类目白名单 | L1/L2 必须来自 `cat_l12_map`，且 L2 隶属 L1 | `ERR_CAT_L12_INVALID`。 |
| L3 粒度 | L3 不能是品牌词、场景词、过泛词 | 标记 `WARN_CAT_L3_WEAK` 并下调置信度；严重时 `ERR_CAT_L3_INVALID`。 |
| 商品方向关联 | `interest_products[].category_hint` 的 L1/L2 必须来自 `cat_l12_map` 白名单，且与所属兴趣簇的 `supply_boundary` 语义一致 | `ERR_PRODUCT_CATEGORY_UNLINKED`。 |
| 消费角色枚举 | role_code 必须来自 10 个角色 taxonomy | `ERR_ROLE_ENUM_INVALID`。 |
| China-VALS 标签 | `vals_layer`、`vals_type`、`vals_tribe` 必须命中受控集合 | `ERR_PERSONA_VALS_INVALID`。 |
| 消费能力枚举 | `spend_power_code/label` 必须匹配五档 | `ERR_SPEND_POWER_INVALID`。 |
| 场景质量 | `scene_name` 不得等同类目名，必须有 `need_summary` 和证据 | `ERR_SCENE_QUALITY_LOW` 或下调置信度。 |
| 泛化边界 | 每个 cluster 必须有 `supply_boundary` 和 `do_not_expand_to` | `ERR_SCENE_BOUNDARY_MISSING`。 |
| 负向风险合并 | LLM-4 风险必须进入最终 `negative_signal_radar`，空数组也合法 | 缺失字段时报 `ERR_RISK_MISSING`。 |
| 价格带合理性 | 类目价格带和商品推荐价格带必须有层级、范围和含义 | `ERR_PRICE_BAND_MISSING`。 |
| **【V10 新增】兴趣商品价格带完整性** | **每个 `interest_products[]` 条目必须包含完整 `price_band`（含 price_level、typical_range、price_min、price_max），且 price_min/price_max 为有效数字，不得为空或 null。若 LLM-6 未为某兴趣商品输出完整价格带，A1 须标记警告并降低该商品的 confidence。** | **`ERR_PRICE_BAND_MISSING` 或 `WARN_PRICE_BAND_INCOMPLETE`。** |
| **【本次新增】角色-价格带绑定一致性** | **每个 `interest_products[]` 条目必须包含 `role_price_context` 字段（含 role_price_sensitivity、role_decision_focus、role_spend_tendency）。同一兴趣簇下若存在多个不同 target_role 的商品，其 price_band.price_level 不得全部相同（即角色差异化必须体现在价格带上）。若全部相同，A1 须标记 `WARN_ROLE_PRICE_UNIFORM` 并降低相关商品的 confidence。** | **`WARN_ROLE_PRICE_CONTEXT_MISSING` 或 `WARN_ROLE_PRICE_UNIFORM`。** |
| 敏感表达 | 不得出现外貌、真实年龄、收入阶层、身份刻板印象或贬损词 | `ERR_SENSITIVE_INFERENCE`。 |
| 置信度范围 | 所有 confidence 在 0—1 | 自动截断并记录 `WARN_CONF_ADJUSTED`。 |

### 13.7 A1 错误输出格式

```json
{
  "inputValidation": false,
  "error_code": "ERR_CAT_L12_INVALID",
  "error_text": "存在不在类目表白名单中的一级或二级类目。",
  "qc_report": {
    "failed_node": "A1",
    "failed_paths": ["interest_scene_graph[0].interest_clusters[0].interest_products[1].category_hint"],
    "suggestion": "检查 LLM-5 的类目白名单约束，或检查 category_l12_file 是否完整。",
    "warnings": []
  }
}
```


---

## 十四、最终 End 节点输出策略

End 节点建议只输出 A1 的成功结果或错误结果，不再拼接上游调试字段。如果需要内部排障，可将 `qc_report`、`input_qc`、`batch_qc` 和上游节点原始输出写入日志系统，而不是进入前端画像主体。

| 场景 | End 输出 | 前端/调用方建议 |
| --- | --- | --- |
| A1 成功 | V9 JSON | 直接展示消费人格、消费角色、兴趣场景、兴趣簇、兴趣商品（含价格带）、内容触达和风险雷达。 |
| P0 输入失败 | 结构化错误 | 提示重新上传用户 JSON 或类目表，通常不扣费或进入异常处理。 |
| LLM 节点输入为空 | 对应节点错误或空结果 | 根据业务规则决定是否返回低置信画像或失败。 |
| A1 质检失败 | 结构化错误 + `qc_report` | 定位节点和字段路径，进入人工排障或自动重跑。 |

---

## 十五、最终 V9 输出完整骨架

以下是 A1 成功后最终对外输出的标准骨架。真实输出不得包含 Markdown、注释或过程字段。

```json
{
  "uid": "123456789",
  "consumption_interest_profile": {
    "consumption_persona": {
      "persona_name": "双轨价值分层型用户",
      "persona_summary": "该用户在日用服饰、食品和个护等类目中表现为价格敏感和实用补给，在部分有证据的高价值类目中存在品质或信任驱动的上探能力。推荐时应以真实试用、材质讲解、价格透明和售后确定性为核心，避免将局部高客单能力泛化为全局高消费力。",
      "persona_tags": {
        "vals_layer": "第二层-效率实用与家庭责任",
        "vals_type": "实用享乐混合型",
        "vals_tribe": "精明消费族"
      },
      "core_traits": [
        "日用和基础类目偏向性价比与低试错成本。",
        "有证据类目可进行有限品质上探。",
        "对真实测评、价格透明和售后保障较敏感。"
      ],
      "confidence": 0.82
    },
    "dominant_role_summary": "以自用实用和价格优化为主，存在局部悦己改善或内容种草辅助信号。",
    "consumption_roles": [
      {
        "role_id": "ROLE_PRICE_OPTIMIZER",
        "role_name": "价格优化型",
        "role_target": "给自己或家庭日常使用场景购买",
        "role_motivation": "用较低试错成本满足明确需求。",
        "decision_focus": ["性价比", "优惠确定性", "实用功能"],
        "price_sensitivity": "价格敏感度较高，适合 entry/value 价格带承接。",
        "trust_requirement": "需要价格透明、真实评价和低风险售后承诺。",
        "confidence": 0.78
      }
    ]
  },
  "interest_scene_graph": [
    {
      "scene_id": "S001",
      "scene_name": "睡眠降噪与日常舒适度改善",
      "linked_roles": ["ROLE_SELF_IMPROVEMENT", "ROLE_SELF_USE_PRAGMATIC"],
      "need_summary": "用户在睡眠质量改善、日常噪音隔离等舒适度提升场景下存在多元供给需求。",
      "priority": "P0",
      "confidence": 0.80,
      "interest_clusters": [
        {
          "cluster_id": "C001",
          "cluster_name": "助眠降噪综合小件",
          "demand_summary": "围绕睡眠场景，提供从耳部隔音到眼部遮光、颈部支撑的完整睡眠舒适供给。",
          "cluster_weight": 0.82,
          "supply_boundary": ["睡眠耳塞", "隔音耳罩", "遮光眼罩", "助眠枕头", "午睡颈枕", "白噪音机"],
          "do_not_expand_to": ["高客单医疗助眠设备", "无证据的全套寝具升级", "跨品类保健药品"],
          "interest_products": [
            {
              "product_id": "IP_S001_C001_001",
              "product_name": "防噪降噪睡眠耳塞（硅胶多规格组合装）",
              "product_description": "用于睡眠场景隔音降噪，柔软硅胶材质，适合不同耳道尺寸，组合装低试错成本。",
              "interest_type": "short_term_interest",
              "target_role": "ROLE_SELF_USE_PRAGMATIC",
              "category_hint": {
                "category_level_1_name": "家居/家纺",
                "category_level_2_name": "家居日用",
                "category_level_3_name_hint": "睡眠耳塞"
              },
              "price_band": {
                "price_level": "entry",
                "typical_range": "9-39元",
                "band_meaning": "低试错成本小件，首次探索适合 entry 价格带，组合装更具性价比。",
                "price_min": 9,
                "price_max": 39,
                "price_anchor_type": "历史价格锚点 + 类目常识"
              },
              "selling_point_logic": "强调材质柔软、隔音分贝数据、多规格适配、组合装低试错。",
              "content_trigger": "场景演示睡眠环境降噪对比，真实试用不同材质舒适度。",
              "reasoning": "用户有直接耳塞购买历史，属于直接证据承接，复购或升级方向明确。",
              "risk_note": "不建议推荐高客单医疗级降噪设备，证据仅支持日用小件。",
              "confidence": 0.86
            },
            {
              "product_id": "IP_S001_C001_002",
              "product_name": "遮光睡眠眼罩（3D立体/冷热双用款）",
              "product_description": "配合睡眠场景使用，提供全遮光效果，3D立体设计不压眼球，适合午睡与夜间使用。",
              "interest_type": "potential_interest_probe",
              "target_role": "ROLE_SELF_IMPROVEMENT",
              "category_hint": {
                "category_level_1_name": "家居/家纺",
                "category_level_2_name": "家居日用",
                "category_level_3_name_hint": "遮光眼罩"
              },
              "price_band": {
                "price_level": "value",
                "typical_range": "15-59元",
                "band_meaning": "中低价格带探索，内容种草配合场景演示激活潜在兴趣。",
                "price_min": 15,
                "price_max": 59,
                "price_anchor_type": "类目保守估算"
              },
              "selling_point_logic": "强调遮光率、3D不压眼、冷热双用适应不同季节需求。",
              "content_trigger": "短视频展示午睡场景，强调遮光体验感提升睡眠质量。",
              "reasoning": "由睡眠降噪需求场景泛化推理，与耳塞形成互补，低门槛试探。",
              "risk_note": "用户尚无直接眼罩购买证据，应以内容种草低门槛试探为主。",
              "confidence": 0.65
            },
            {
              "product_id": "IP_S001_C001_003",
              "product_name": "午睡助眠颈枕（记忆棉U型款）",
              "product_description": "为午睡场景提供颈部支撑，记忆棉材质，便携可折叠，适合办公室和通勤使用。",
              "interest_type": "potential_interest_probe",
              "target_role": "ROLE_SELF_IMPROVEMENT",
              "category_hint": {
                "category_level_1_name": "家居/家纺",
                "category_level_2_name": "家纺",
                "category_level_3_name_hint": "颈枕"
              },
              "price_band": {
                "price_level": "value",
                "typical_range": "29-89元",
                "band_meaning": "中低价格带，性价比款可内容试探，强证据出现后可适度上探。",
                "price_min": 29,
                "price_max": 89,
                "price_anchor_type": "类目保守估算"
              },
              "selling_point_logic": "强调颈部支撑、便携收纳、记忆棉贴合度，适合多场景使用。",
              "content_trigger": "通勤午睡场景演示，对比有无颈枕的睡眠舒适度差异。",
              "reasoning": "睡眠舒适度场景内互补商品，与耳塞/眼罩共同构成完整睡眠套件。",
              "risk_note": "用户无直接颈枕购买证据，属于场景泛化推理，应以低门槛探索为主。",
              "confidence": 0.60
            }
          ]
        }
      ]
    }
  ],
  "content_anchor_delivery": {
    "preferred_content_formats": ["真实测评", "场景演示", "价格对比", "材质讲解"],
    "trust_triggers": ["价格透明", "真实评价", "售后保障"],
    "avoid_content": ["夸大功效", "高压促单", "无证据高客单种草"],
    "channel_handoff": "短视频负责场景种草和知识解释，泛货架搜索承接显性需求，直播间负责价格解释、信任补强和实时答疑。",
    "confidence": 0.8
  },
  "negative_signal_radar": [
    {
      "signal_id": "risk_001",
      "signal_type": "price_overreach",
      "severity": "medium_high",
      "affected_objects": ["CAT_S001_C001_001"],
      "risk_reasoning": "该类目历史价格锚点偏中低，不宜直接推荐高客单品牌款。",
      "mitigation_hint": "优先使用 entry/value 价格带验证兴趣，强信任证据出现后再逐步上探。"
    }
  ]
}
```

---

## 十六、落地质检清单（V10 更新）

在真实搭建时，建议先用 5 到 10 个典型用户样本做链路冒烟测试，再进入批量评测。测试时不只看 JSON 是否能解析，还要看场景命名、类目映射、价格带、角色边界和风险是否符合业务常识。

| 检查项 | 合格标准 | 常见问题 |
| --- | --- | --- |
| JSON 可解析 | 所有 LLM 节点只输出合法 JSON | 模型输出 Markdown、注释或额外解释。 |
| 字段稳定 | 字段名与协议完全一致 | LLM 自创字段或遗漏 `error_code`、`error_text`。 |
| 类目白名单 | L1/L2 均命中 `cat_l12_map` | LLM 输出不存在的二级类目。 |
| 场景命名 | 场景是需求语境，不是类目名 | 输出"服饰兴趣""食品兴趣"。 |
| **【V10】场景内聚** | **同一场景下兴趣簇必须共享核心需求维度，不得跨需求域混合归并** | **"夏季日常补给与换季添置"同时包含饮食和穿搭。** |
| 泛化边界 | 每个簇都有 `do_not_expand_to` | 商品方向扩得过远。 |
| **【V10】兴趣簇泛化** | **每个兴趣簇的 supply_boundary 必须基于场景语境主动推理完整供给集合，不得仅列出输入数据已有商品** | **"睡眠降噪场景"的 supply_boundary 只有耳塞，未泛化眼罩/枕头等。** |
| **【V10】兴趣簇去重** | **同一场景内任意两个兴趣簇语义不得高度重叠，本质相同的兴趣簇须合并** | **"助眠隔音小件"与"隔音耳部防护配件"同时存在。** |
| **【V10】商品方向数量** | **每个兴趣簇必须有至少 3 个不同兴趣商品（LLM-6 输出）** | **每个兴趣簇仅推荐1个商品，选择过少。** |
| 价格带 | 每个兴趣商品均有价格层级、范围和含义 | 只输出"中等价格"，没有区间。 |
| **【V10】价格带联通** | **每个兴趣商品条目必须包含完整 price_band（price_level、typical_range、price_min、price_max），来源可追溯至 LLM-6 输出** | **价格带为空或 price_min/price_max 为 null。** |
| **【V10】角色差异价格带** | **同一用户在不同消费角色下的价格带须差异化输出，不得以最高单笔价格锚定全部角色** | **所有角色统一使用用户历史最高单笔订单金额作为价格上限。** |
| **【本次新增】角色-消费画像价格带绑定** | **每个兴趣商品必须有 `role_price_context` 字段，且 price_band 必须反映 consumption_profile.role_mix 中对应角色的 price_sensitivity 和 decision_focus；同一兴趣簇下不同 target_role 的商品 price_level 不得全部相同** | **所有商品 price_level 一致，角色差异未体现在价格带上；或 role_price_context 字段缺失。** |
| 角色表达 | 多角色并存但不凑数 | 把所有用户都输出家庭、礼赠、悦己。 |
| 风险合并 | LLM-4 风险进入最终结果 | 负向信号丢失或提前进入 LLM-5。 |
| 敏感治理 | 不输出身份、收入、外貌、身体、婚育等推断 | "宝妈""高收入""身体差"等违规表达。 |
| 数量控制 | 场景 ≤ 3，簇 ≤ 3，每簇兴趣商品 ≤ 5 | 输出过多弱场景，前端无法承接。 |

---

## 十七、推荐实施顺序

建议先按 P0、P1、LLM-1、LLM-2、LLM-5、Batch、LLM-6、A1 的主链路打通，再并行接入 LLM-3 和 LLM-4。这样可以优先验证"消费画像 → 兴趣候选 → 场景/簇/类目 → 商品方向 → V9 装配"的主干是否稳定。主干稳定后，再用 LLM-3 增强触达画像，用 LLM-4 增强负向风险边界。

| 阶段 | 目标 | 验收标准 |
| --- | --- | --- |
| 第一阶段 | 跑通 P0/P1/A1 基础结构 | 输入解析、类目表解析、错误输出和空结果处理稳定。 |
| 第二阶段 | 跑通 LLM-1/LLM-2/LLM-5 主推理 | 能生成合理消费人格、兴趣候选和场景骨架；场景内聚性和兴趣簇去重通过自检。 |
| 第三阶段 | 接入 Batch/LLM-6 | 每个场景每个兴趣簇能补全至少 3 个商品方向，价格带按角色差异化输出。 |
| 第四阶段 | 接入 LLM-3/LLM-4 | 内容触达和风险雷达能进入最终 V9。 |
| 第五阶段 | 批量样本评测 | JSON 合法率、类目合法率、兴趣簇内聚率、价格带联通率、敏感表达拦截率、人工可读性达到上线要求。 |

---

## 十八、结论

这版 V10 完整 Workflow 在 V9 基础上，针对实验运行中发现的六类核心推理质量问题进行了定向修复：

1. **LLM-1**：增加角色维度价格弹性，避免最高单笔价格锚定所有角色价格带。
2. **LLM-5**：增加场景内聚性约束，确保同一场景下兴趣簇语义相关；强制兴趣簇主动泛化供给集合，避免仅反映输入数据已有商品；增加兴趣簇去重自检，消除边界模糊的重叠兴趣簇。
3. **LLM-6**：强制每个兴趣簇输出至少 3 个商品方向；增加角色-场景差异化价格带规则；要求每个商品方向条目完整携带价格带字段，保障「兴趣商品→价格带」链路贯通。
4. **A1**：新增价格带与兴趣商品联通质检规则，确保价格带回填完整，链路可追溯。

整体链路保持「消费角色 → 兴趣场景 → 兴趣簇 → 兴趣商品 → 价格带」的完整闭环，前端和策略同学看到的是高质量、内聚、泛化充分的需求图谱；工程侧看到的是可程序化质检的 Schema 约束和清晰的节点责任边界。

